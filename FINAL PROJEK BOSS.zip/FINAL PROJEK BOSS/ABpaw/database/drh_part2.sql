-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2026 at 05:42 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drh_part2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`) VALUES
(1, 'Bunciss', '$2a$10$VNjF9RJJY5yZVwNbj.NktezEmF9AGgZhCoRtwLsK1q7wC6uW9EvXW', 'Bylbiss El Haqqie', 'bylbiss@gmail.com', '2026-04-29 05:47:55', '2026-05-17 06:41:23'),
(2, 'Ipeh', '$2a$10$hCKjp4WJ6gUtmD2lV7stlO/A6oOjRgYYhV3xEqEC3FTmpG7JUj5Si', 'Alifah Chairul Munawar', 'orangimut@gmail.com', '2026-04-29 06:03:06', '2026-05-17 06:41:23');

-- --------------------------------------------------------

--
-- Table structure for table `alergi_pet`
--

CREATE TABLE `alergi_pet` (
  `id_alergi` int(11) NOT NULL,
  `id_pet` int(11) NOT NULL,
  `id_obat` int(11) DEFAULT NULL,
  `nama_alergi` text DEFAULT NULL,
  `created_by_type` enum('pemilik','dokter') NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `status` enum('usulan','terverifikasi') DEFAULT 'usulan',
  `verified_by` int(11) DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id_chat` int(11) NOT NULL,
  `id_dokter` int(11) DEFAULT NULL,
  `id_pemilik` int(11) DEFAULT NULL,
  `pesan` text DEFAULT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp(),
  `status_baca` enum('unread','read') DEFAULT 'unread',
  `pengirim` enum('dokter','pemilik') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id_chat`, `id_dokter`, `id_pemilik`, `pesan`, `waktu`, `status_baca`, `pengirim`) VALUES
(33, 5, 2, 'halo dok', '2026-05-16 16:14:21', 'read', 'pemilik'),
(34, 5, 2, 'selamat malam dengan kak kubro', '2026-05-16 16:14:46', 'read', 'pemilik'),
(35, 2, 6, 'halo dokter', '2026-05-17 06:44:25', 'read', 'pemilik'),
(36, 2, 6, 'jadi gini dok', '2026-05-17 06:45:07', 'read', 'pemilik'),
(37, 2, 6, 'kalo dokter', '2026-05-17 08:20:38', 'read', 'pemilik'),
(38, 2, 6, 'iya gimana?', '2026-05-17 08:21:14', 'read', 'pemilik'),
(39, 2, 6, 'halo dok', '2026-05-17 08:22:11', 'read', 'pemilik'),
(40, 2, 6, 'halo', '2026-05-18 13:12:56', 'unread', 'pemilik'),
(41, 1, 6, 'halo dokter', '2026-05-18 13:20:19', 'read', 'pemilik'),
(42, 1, 6, 'halo kak', '2026-05-18 13:21:03', 'read', 'pemilik'),
(43, 2, NULL, 'halo dokterr', '2026-05-18 13:57:32', 'unread', 'pemilik'),
(44, 2, NULL, 'halo dokterrrr', '2026-05-18 13:57:43', 'unread', 'pemilik'),
(45, 2, NULL, 'halo dokterrrr', '2026-05-18 14:07:54', 'unread', 'pemilik'),
(46, 2, NULL, 'halo dokter', '2026-05-18 14:09:50', 'unread', 'pemilik'),
(47, 1, NULL, 'halo dokter', '2026-05-18 14:10:06', 'unread', 'pemilik'),
(48, 1, NULL, 'halo dok', '2026-05-18 14:10:11', 'unread', 'pemilik'),
(49, 2, 6, 'halo dok', '2026-05-18 14:14:02', 'unread', 'pemilik'),
(50, 1, 6, 'halo dok', '2026-05-18 15:10:26', 'read', 'pemilik'),
(51, 1, 6, 'dok', '2026-05-18 15:10:29', 'read', 'pemilik'),
(52, 1, 6, 'iya gimana keadaan hewannya kak?', '2026-05-18 15:11:12', 'read', 'dokter'),
(53, 1, 6, 'dok', '2026-05-18 15:38:15', 'read', 'pemilik');

-- --------------------------------------------------------

--
-- Table structure for table `detail_resep`
--

CREATE TABLE `detail_resep` (
  `id_detail` int(11) NOT NULL,
  `id_resep` int(11) NOT NULL,
  `id_obat` int(11) NOT NULL,
  `takaran` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `catatan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_resep`
--

INSERT INTO `detail_resep` (`id_detail`, `id_resep`, `id_obat`, `takaran`, `jumlah`, `catatan`) VALUES
(1, 3, 8, '1x1vhf', 1, NULL),
(2, 4, 9, '3x1', 2, NULL),
(3, 5, 4, '2x1', 1, NULL),
(4, 6, 11, '1x1', 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `id_dokter` int(11) NOT NULL,
  `nama_depan` varchar(50) DEFAULT NULL,
  `nama_belakang` varchar(50) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `alamat` text DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `spesialisasi` varchar(100) DEFAULT NULL,
  `biaya_konsultasi` decimal(10,2) DEFAULT NULL,
  `spesies_hewan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `nama_depan`, `nama_belakang`, `username`, `password`, `email`, `alamat`, `no_hp`, `spesialisasi`, `biaya_konsultasi`, `spesies_hewan`, `created_at`, `updated_at`) VALUES
(1, 'Aidan', 'Elvano Pratama', 'aidan1', '$2a$10$gPz2A71vZRlxjNix./VIs.ofdyzV9oSyerG/Sf5l0Wy9mLL828h/u', 'aidan.elvanopratama@abpaw.com', 'Jl. Kaliurang Km 5', '081234567890', 'Dokter Umum', 80000.00, 'ikan, burung, domba', '2026-04-29 07:50:57', '2026-05-17 06:41:01'),
(2, 'Keano', 'Alfarez Julian', 'keano2', '$2a$10$yql9dvBmn4x8SMwv.sjWou0xcffE1wih3RnYsGZ3dGmexy01BSru2', 'keano.alfarezjulian@abpaw.com', 'Jl. Malioboro No.12', '082345678901', 'Spesialis Penyakit Dalam', 150000.00, 'ayam, kambing, kuda, kura-kura, hamster', '2026-04-29 07:50:57', '2026-05-17 06:41:02'),
(3, 'Zayden', 'Khalish Mahatma', 'zayden3', '$2a$10$1JyR9EuEKZsm9hSZ2tZy1erh.94976R6ra4mse3gtEZjXTqbfUZqy', 'zayden.khalishmahatma@abpaw.com', 'Jl. Gejayan No.45', '083456789012', 'Spesialis Gigi', 150000.00, 'landak, sapi, musang, domba, hamster', '2026-04-29 07:50:57', '2026-05-17 06:41:02'),
(4, 'Ghaisan', 'Kenzo', 'ghaisan4', '$2a$10$4xAy4Boy8sH6YPfoOGIYce9CrgWxnIbhSpOCr9LvYgRrQGOOWmUfi', 'ghaisan.kenzo@abpaw.com', 'Jl. Parangtritis Km 6', '084567890123', 'Spesialis Parasitologi & Infeksi', 150000.00, 'kuda, hamster, domba, musang, monyet', '2026-04-29 07:50:57', '2026-05-17 06:41:02'),
(5, 'Zayn', 'Alby Rajendra', 'zayn5', '$2a$10$Vm.JDCT0ssVnC1go0iowteEPZZth0ErgcXx5zZPw2herlVOu40yIK', 'zayn.albyrajendra@abpaw.com', 'Jl. Magelang Km 7', '085678901234', 'Spesialis Reproduksi', 150000.00, 'kerbau, kambing, kuda', '2026-04-29 07:50:57', '2026-05-17 06:41:02'),
(6, 'Ahmad', 'Fauzi Hasan', 'ahmad6', '$2a$10$D.t9L7K3VbjyyuDc.j4.JO/iKUbF7yWoNsK5onBTh3ktTCZdUfAKS', 'ahmad.fauzihasan@abpaw.com', 'Jl. Wonosari Km 8', '086789012345', 'Spesialis Gigi', 150000.00, 'ayam, kuda, kelinci, ikan', '2026-04-29 07:50:57', '2026-05-17 06:41:02'),
(7, 'Dewi', 'Kartika Sari', 'dewi7', '$2a$10$CO4/tTGcGaSCuoAxuTKRaOTmSkg9njy49SvCQBDDy1tfFVs5t5go.', 'dewi.kartikasari@abpaw.com', 'Jl. Imogiri Timur No.21', '087890123456', 'Spesialis Reproduksi', 150000.00, 'hamster, musang, anjing, kerbau, kuda', '2026-04-29 07:50:57', '2026-05-17 06:41:02'),
(8, 'Eko', 'Prasetyo Wibowo', 'eko8', '$2a$10$glPc5.jS44hAe6iLo7MhXuvTId3EaEuIp8BLlE/Pob8mQNgCK7b/O', 'eko.prasetyowibowo@abpaw.com', 'Jl. Bantul Km 9', '088901234567', 'Spesialis Parasitologi & Infeksi', 150000.00, 'sapi, kambing, kelinci, burung, domba', '2026-04-29 07:50:57', '2026-05-17 06:41:03'),
(9, 'Fitria', 'Nur Aini', 'fitria9', '$2a$10$Lw9IW3I6VSynHRym/pF1yuHR.KKs0l7U1frzGyxDUSy/wiy4o1kdu', 'fitria.nuraini@abpaw.com', 'Jl. Godean Km 4', '089012345678', 'Spesialis Parasitologi & Infeksi', 150000.00, 'ikan, hamster, kerbau', '2026-04-29 07:50:57', '2026-05-17 06:41:03'),
(10, 'Gilang', 'Maulana Ibrahim', 'gilang10', '$2a$10$ccZXr.fPBqYblkek9k0w9Ok81OXFMycEnGFmRWwTFpmdn9j.slYr2', 'gilang.maulanaibrahim@abpaw.com', 'Jl. Kaliurang Km 10', '081112223334', 'Spesialis Reproduksi', 150000.00, 'kura-kura, monyet, kelinci', '2026-04-29 07:50:57', '2026-05-17 06:41:03'),
(11, 'Hani', 'Fadilah Zahra', 'hani11', '$2a$10$sZiu6r1IdkEoyrZ.um.rGuxmxi9L2kmsHZ9GP3jdYwCNOASk7vIcC', 'hani.fadilahzahra@abpaw.com', 'Jl. Malioboro No.22', '082223334445', 'Spesialis Penyakit Dalam', 150000.00, 'babi, kelinci, domba, ayam', '2026-04-29 07:50:57', '2026-05-17 06:41:03'),
(12, 'Indra', 'Kusuma Wardhana', 'indra12', '$2a$10$pW1vgm5vFjxwPI.OI0CvgOD83Mcwq4IF05spSjjvQmXZ836wBiAfS', 'indra.kusumawardhana@abpaw.com', 'Jl. Gejayan No.67', '083334445556', 'Dokter Umum', 80000.00, 'monyet, kuda, burung, musang, ayam', '2026-04-29 07:50:57', '2026-05-17 06:41:03'),
(13, 'Joko', 'Susilo Adi', 'joko13', '$2a$10$trwD4l0t5HyImh/LN87xeO/srHt7nlYb6qsaYiFH9wKizT5r9ijGG', 'joko.susiloadi@abpaw.com', 'Jl. Parangtritis Km 7', '084445556667', 'Spesialis Kulit', 150000.00, 'sapi, kerbau, babi, kuda, kucing', '2026-04-29 07:50:57', '2026-05-17 06:41:04'),
(14, 'Kartika', 'Sari Dewi', 'kartika14', '$2a$10$rKbpOEvCFk83WhYGTbHI9.L7iBKIS2R/O9cp6j8zTqwJhWPhWkPUO', 'kartika.saridewi@abpaw.com', 'Jl. Magelang Km 5', '085556667778', 'Dokter Umum', 80000.00, 'hamster, kambing, kuda, musang, domba', '2026-04-29 07:50:57', '2026-05-17 06:41:04'),
(15, 'Laksmi', 'Dewi Andini', 'laksmi15', '$2a$10$VaYCEz73zCZZB85ydMnKGOseaDwNhZu.kg1br1DVrL6HVgRfkzbD6', 'laksmi.dewiandini@abpaw.com', 'Jl. Wonosari Km 6', '086667778889', 'Spesialis Gigi', 150000.00, 'hamster, kura-kura, ayam, musang', '2026-04-29 07:50:57', '2026-05-17 06:41:04'),
(16, 'Mila', 'Rahmawati Putri', 'mila16', '$2a$10$XS67N9mvopECdAx0E8JBnuZAKZVkar3HipbzIYEbW7EkErlTK2LBu', 'mila.rahmawatiputri@abpaw.com', 'Jl. Imogiri Barat No.10', '087778889990', 'Spesialis Reproduksi', 150000.00, 'kerbau, landak, kura-kura, burung', '2026-04-29 07:50:57', '2026-05-17 06:41:04'),
(17, 'Nanda', 'Kurniawan Setiawan', 'nanda17', '$2a$10$xly3/z3SKYMFuNyXx71eceKYOdSDjcvIOqGKtPmAlLpsGhWOwYTHq', 'nanda.kurniawansetiawan@abpaw.com', 'Jl. Bantul Km 10', '088889990001', 'Spesialis Reproduksi', 150000.00, 'ayam, kuda, kucing, burung', '2026-04-29 07:50:57', '2026-05-17 06:41:04'),
(18, 'Olivia', 'Sari Puspita', 'olivia18', '$2a$10$.V9xEZerO7m/9ItJRImq3.W6PdkGvJ/vZIJwIHKYXxQ3Q8DCKLcmm', 'olivia.saripuspita@abpaw.com', 'Jl. Godean Km 6', '089990001112', 'Spesialis Kulit', 150000.00, 'kura-kura, kerbau, babi, ikan, ayam', '2026-04-29 07:50:57', '2026-05-17 06:41:05'),
(19, 'Putri', 'Ayu Lestari', 'putri19', '$2a$10$jQarU/4wQBR32DA6GnmRyu2KGJgZ1goSb.utMZa6wltNbMwpnUMOC', 'putri.ayulestari@abpaw.com', 'Jl. Kaliurang Km 8', '081223344556', 'Dokter Umum', 80000.00, 'burung, kerbau, kura-kura, monyet, ikan', '2026-04-29 07:50:57', '2026-05-17 06:41:05'),
(20, 'Qori', 'Hidayatullah Firdaus', 'qori20', '$2a$10$OvO1UXJsJgr/dJS1ThRfQeHYcQCkoyD7SHzlMPy7yjpmPPoYJIB1W', 'qori.hidayatullahfirdaus@abpaw.com', 'Jl. Malioboro No.30', '082334455667', 'Spesialis Reproduksi', 150000.00, 'ayam, kuda, kerbau, kambing', '2026-04-29 07:50:57', '2026-05-17 06:41:05'),
(21, 'Rina', 'Amelia Putri', 'rina21', '$2a$10$Qr5q8a/BZltzGHX3NiYWc.OR8tICqFIYfnFE5/H8YGKrX/7RCv1a6', 'rina.ameliaputri@abpaw.com', 'Jl. Gejayan No.90', '083445566778', 'Spesialis Bedah', 150000.00, 'musang, kuda, kura-kura', '2026-04-29 07:50:57', '2026-05-17 06:41:06'),
(22, 'Sari', 'Yuliana Safitri', 'sari22', '$2a$10$1ShkwYu330e6FJndtbgTs.zpLqtsVkarLVRqJfLkh5w1otXqueW1m', 'sari.yulianasafitri@abpaw.com', 'Jl. Parangtritis Km 5', '084556677889', 'Spesialis Penyakit Dalam', 150000.00, 'kura-kura, kelinci, burung, kuda', '2026-04-29 07:50:57', '2026-05-17 06:41:06'),
(23, 'Teguh', 'Prasetyo Utomo', 'teguh23', '$2a$10$GpfNurevFSiIlo1Tc1q4ououME81Kx563Bprhf9uFpWZLAzxuKg..', 'teguh.prasetyoutomo@abpaw.com', 'Jl. Magelang Km 3', '085667788990', 'Dokter Umum', 80000.00, 'sapi, kucing, landak, babi', '2026-04-29 07:50:57', '2026-05-17 06:41:06'),
(24, 'Umi', 'Kalsum Azizah', 'umi24', '$2a$10$uGN1uFIjBMyFPr.DjR3LReOcJXEyz7erPOskE5rnALWtwUSyr.RRi', 'umi.kalsumazizah@abpaw.com', 'Jl. Wonosari Km 4', '086778899001', 'Spesialis Gigi', 150000.00, 'landak, burung, babi, anjing', '2026-04-29 07:50:57', '2026-05-17 06:41:06'),
(25, 'Vina', 'Meliana Putri', 'vina25', '$2a$10$o7As6HjogbDjuZUCF./tfu7x4ZUHaWAk4BfcI622Ud6gj6j0etn86', 'vina.melianaputri@abpaw.com', 'Jl. Imogiri Timur No.5', '087889900112', 'Spesialis Kulit', 150000.00, 'ayam, ikan, kelinci', '2026-04-29 07:50:57', '2026-05-17 06:41:07'),
(26, 'Wawan', 'Setiawan Budi', 'wawan26', '$2a$10$MEsuQyuNS3MtzcajRikdj.7Egd1iB14zalssTUfn3EUn5DHdsK6UW', 'wawan.setiawanbudi@abpaw.com', 'Jl. Bantul Km 11', '088990011223', 'Spesialis Kulit', 150000.00, 'sapi, babi, ikan, kelinci', '2026-04-29 07:50:57', '2026-05-17 06:41:07'),
(27, 'Xenia', 'Ayu Kirana', 'xenia27', '$2a$10$3xGY.XJBUBW7GrkOPVlDY.Oj8YxakaDkjcu/k4./GL8k6jebG.UEi', 'xenia.ayukirana@abpaw.com', 'Jl. Godean Km 7', '089001122334', 'Dokter Umum', 80000.00, 'anjing, kambing, kerbau, ikan', '2026-04-29 07:50:57', '2026-05-17 06:41:07'),
(28, 'Yuni', 'Susilawati Indah', 'yuni28', '$2a$10$TZDw7sLvo4xx9ID7yiBUduuvjWJDGymljglpxHnSxZEMgle9MmqAq', 'yuni.susilawatiindah@abpaw.com', 'Jl. Kaliurang Km 12', '081334455667', 'Spesialis Reproduksi', 150000.00, 'babi, musang, anjing, kuda, ikan', '2026-04-29 07:50:57', '2026-05-17 06:41:07'),
(29, 'Zaki', 'Ahmad Firdaus', 'zaki29', '$2a$10$EJVMPyhKj7231g1jPJeRg.qOvI0zWhAQ7M6T2MGOkxM5lIxc9AOnq', 'zaki.ahmadfirdaus@abpaw.com', 'Jl. Malioboro No.40', '082445566778', 'Spesialis Parasitologi & Infeksi', 150000.00, 'ikan, hamster, sapi', '2026-04-29 07:50:57', '2026-05-17 06:41:07'),
(30, 'Ani', 'Mardiana Wati', 'ani30', '$2a$10$yC8wqlqUXp0gYWwX5pS/YOrsdbV2O/KhJEggUyk/Y9vVr3tnKTexe', 'ani.mardianawati@abpaw.com', 'Jl. Gejayan No.100', '083556677889', 'Spesialis Parasitologi & Infeksi', 150000.00, 'anjing, kucing, sapi, babi, domba', '2026-04-29 07:50:57', '2026-05-17 06:41:07'),
(31, 'Ahmad', 'Rizki Maulana Syahputra', 'ahmad31', '$2a$10$AtYNIF3ew0PzE2fbuBeY4.3DSOfnXS041.dF9PO4u8.CEyTtmwqN6', 'ahmad.rizkimaulanasyahputra@abpaw.com', 'Jl. Parangtritis Km 9', '084667788990', 'Spesialis Reproduksi', 150000.00, 'musang, ikan, sapi, domba, kucing', '2026-04-29 07:50:57', '2026-05-17 06:41:08'),
(32, 'Dewi', 'Lestari Ayu Ningsih', 'dewi32', '$2a$10$vUyERupN7ukDBi7jHMdFKuydPMRMLXKHBDIdAY0bulBjiOLYmVcD2', 'dewi.lestariayuningsih@abpaw.com', 'Jl. Magelang Km 2', '085778899001', 'Spesialis Bedah', 150000.00, 'sapi, kelinci, kuda, musang', '2026-04-29 07:50:57', '2026-05-17 06:41:08'),
(33, 'Eko', 'Budi Santoso Raharjo', 'eko33', '$2a$10$2D4pa180gbl9CC/AGph3X.m/fcV8juhPduY6cQXewlaDkbFjHARe2', 'eko.budisantosoraharjo@abpaw.com', 'Jl. Wonosari Km 10', '086889900112', 'Dokter Umum', 80000.00, 'burung, landak, anjing, kucing', '2026-04-29 07:50:57', '2026-05-17 06:41:08'),
(34, 'Fitri', 'Handayani Sari Utami', 'fitri34', '$2a$10$AzsIU855Pbwwh54P3w2Ubu4jCKeoihhIScGN8Lj9TH97E6ljcDtzS', 'fitri.handayanisariutami@abpaw.com', 'Jl. Imogiri Barat No.15', '087990011223', 'Spesialis Parasitologi & Infeksi', 150000.00, 'kerbau, kelinci, kucing', '2026-04-29 07:50:57', '2026-05-17 06:41:08'),
(35, 'Gita', 'Puspita Ayu Lestari', 'gita35', '$2a$10$N6dn5Bl3/irzWlCXzOU1je0eIH0slPDE5.duztkaor7xnzcLgoTiq', 'gita.puspitaayulestari@abpaw.com', 'Jl. Bantul Km 12', '088001122334', 'Spesialis Reproduksi', 150000.00, 'ikan, kura-kura, domba, kerbau, babi', '2026-04-29 07:50:57', '2026-05-17 06:41:09'),
(36, 'Hadi', 'Prasetyo Wibowo Saputra', 'hadi36', '$2a$10$z/.rVs9eVF0QqKThjxwnvOyDQfSgc84fCr1n8vj9jh4RYSOsqW0Ti', 'hadi.prasetyowibowosaputra@abpaw.com', 'Jl. Godean Km 8', '089112233445', 'Dokter Umum', 80000.00, 'monyet, landak, kelinci, ayam', '2026-04-29 07:50:57', '2026-05-17 06:41:09'),
(37, 'Indah', 'Permata Sari Dewi', 'indah37', '$2a$10$Z6pY65Z8TiHfT3MAaxHbp.GKqkRUaNTCY.iG.tdhSsQ36u5EqdjAO', 'indah.permatasaridewi@abpaw.com', 'Jl. Kaliurang Km 15', '081556677889', 'Spesialis Reproduksi', 150000.00, 'babi, musang, ikan, kuda', '2026-04-29 07:50:57', '2026-05-17 06:41:09'),
(38, 'Joko', 'Prasetyo Hadi Susilo', 'joko38', '$2a$10$bQB7LGY21KpCa3.lBR6d8uLu9qS/VTJj5tIkAYg7KVqoG9I1niXUO', 'joko.prasetyohadisusilo@abpaw.com', 'Jl. Malioboro No.50', '082667788990', 'Dokter Umum', 80000.00, 'monyet, domba, kerbau, kuda', '2026-04-29 07:50:57', '2026-05-17 06:41:09'),
(39, 'Kartika', 'Ayu Dewi Lestari', 'kartika39', '$2a$10$XRiByNhlT53PIf2U1e75XuVRlnxsN.PjhcJUxh60b61fPAotZPISO', 'kartika.ayudewilestari@abpaw.com', 'Jl. Gejayan No.120', '083778899001', 'Spesialis Kulit', 150000.00, 'sapi, musang, burung', '2026-04-29 07:50:57', '2026-05-17 06:41:09'),
(40, 'Lina', 'Marlina Sari Puspita', 'lina40', '$2a$10$TjyqI3fsTB47PwdtlNx9reJEgCh15Sa2vR/Ysb4CYGb5O66ifpUxi', 'lina.marlinasaripuspita@abpaw.com', 'Jl. Parangtritis Km 11', '084889900112', 'Spesialis Kulit', 150000.00, 'musang, monyet, kucing, landak', '2026-04-29 07:50:57', '2026-05-17 06:41:10'),
(41, 'Mila', 'Nurul Aini Fadhilah', 'mila41', '$2a$10$5UAcsBZqIYnPr3I9sWX/SOD24pOaY1/apATG1KA7pqIjAXgJo6/A.', 'mila.nurulainifadhilah@abpaw.com', 'Jl. Magelang Km 6', '085990011223', 'Spesialis Gigi', 150000.00, 'musang, ayam, ikan', '2026-04-29 07:50:57', '2026-05-17 06:41:10'),
(42, 'Nanda', 'Kurniawan Hadi Putra', 'nanda42', '$2a$10$kIWt2xm1LWxDaNSmdBo7..7lXOkYHi2HgPEkErqBitjImYrvU5Il6', 'nanda.kurniawanhadiputra@abpaw.com', 'Jl. Wonosari Km 12', '086001122334', 'Spesialis Reproduksi', 150000.00, 'ikan, kura-kura, musang, kambing, burung', '2026-04-29 07:50:57', '2026-05-17 06:41:10'),
(43, 'Olivia', 'Grace Michelle Tan', 'olivia43', '$2a$10$PHgv3FwRbcU3tBB.uUrnC.7wIrEGbqQZlFcvU5yZpE0hRkybUtEdW', 'olivia.gracemichelletan@abpaw.com', 'Jl. Imogiri Timur No.8', '087112233445', 'Spesialis Gigi', 150000.00, 'sapi, kuda, musang, kerbau, domba', '2026-04-29 07:50:57', '2026-05-17 06:41:10'),
(44, 'Putri', 'Aulia Ramadhani Sari', 'putri44', '$2a$10$bQ6MdRMwUg7UEpShNrfMBerc7U72c12KcKstID.MUr/pq1Lhb3Itq', 'putri.auliaramadhanisari@abpaw.com', 'Jl. Bantul Km 13', '088223344556', 'Spesialis Penyakit Dalam', 150000.00, 'kucing, musang, babi', '2026-04-29 07:50:57', '2026-05-17 06:41:10'),
(45, 'Qonita', 'Nur Hidayati Rahma', 'qonita45', '$2a$10$MUpJsgTTziUFaSiQIkka9eSqEbGwdeEpE6Cdgz13AU/2ElSb4oGM.', 'qonita.nurhidayatirahma@abpaw.com', 'Jl. Godean Km 9', '089334455667', 'Spesialis Parasitologi & Infeksi', 150000.00, 'ayam, kuda, monyet', '2026-04-29 07:50:57', '2026-05-17 06:41:11'),
(46, 'Rina', 'Amelia Putri Sari', 'rina46', '$2a$10$vQJ/Pkf.Ya2id2pgw5WUZe0fNeJDYWExb0IOpvSBCPKWx7TrMjfle', 'rina.ameliaputrisari@abpaw.com', 'Jl. Kaliurang Km 20', '081667788990', 'Spesialis Reproduksi', 150000.00, 'ikan, landak, kelinci', '2026-04-29 07:50:57', '2026-05-17 06:41:11'),
(47, 'Sari', 'Ayu Wulandari Pratiwi', 'sari47', '$2a$10$P2MX9Xaco/xXOp7bu5X3OuDIrNLlxAjefAfO.tgFtlyFwu6dQBnh.', 'sari.ayuwulandaripratiwi@abpaw.com', 'Jl. Malioboro No.60', '082778899001', 'Spesialis Kulit', 150000.00, 'monyet, musang, babi, domba, burung', '2026-04-29 07:50:57', '2026-05-17 06:41:11'),
(48, 'Teguh', 'Prasetyo Utomo Saputro', 'teguh48', '$2a$10$JcSkmD1dXBg8Rdxqpm0G1ep6ricgoaKBdQfQUkccpghBQ/of8oGOC', 'teguh.prasetyoutomosaputro@abpaw.com', 'Jl. Gejayan No.140', '083889900112', 'Spesialis Penyakit Dalam', 150000.00, 'kambing, kuda, babi', '2026-04-29 07:50:57', '2026-05-17 06:41:11'),
(49, 'Umi', 'Kulsum Azizah Rahmawati', 'umi49', '$2a$10$/j7rsOHg2b0gQVUm8hNmceIRY6znwZBQsuoHnjNjCvdPJc4Yszn0m', 'umi.kulsumazizahrahmawati@abpaw.com', 'Jl. Parangtritis Km 13', '084990011223', 'Spesialis Kulit', 150000.00, 'kuda, kambing, ayam, domba, babi', '2026-04-29 07:50:57', '2026-05-17 06:41:11'),
(50, 'Vera', 'Meliana Putri Indah', 'vera50', '$2a$10$D7u6khZV4QyyaMk414oU.OOlOSghWEpZ5QP4F2ih..GuUznTc3uhy', 'vera.melianaputriindah@abpaw.com', 'Jl. Magelang Km 9', '085001122334', 'Spesialis Bedah', 150000.00, 'anjing, monyet, ayam, kambing, kura-kura', '2026-04-29 07:50:57', '2026-05-17 06:41:12'),
(51, 'Wawan', 'Setiawan Budi Utomo', 'wawan51', '$2a$10$zquxVD83TBth.32ZZoj3peevqjQ4UFiZav/.H2QDwgoAfZluNH51i', 'wawan.setiawanbudiutomo@abpaw.com', 'Jl. Wonosari Km 14', '086112233445', 'Spesialis Penyakit Dalam', 150000.00, 'kura-kura, anjing, domba, musang', '2026-04-29 07:50:57', '2026-05-17 06:41:12'),
(52, 'Xander', 'Ahmad Fatin Wilopo', 'xander52', '$2a$10$A6ADv7kJsj4ANTQ1mEC3x.N7TIkVEPEmnnwE9DS8.byasAQn0j4SG', 'xander.ahmadfatinwilopo@abpaw.com', 'Jl. Imogiri Barat No.20', '087223344556', 'Spesialis Penyakit Dalam', 150000.00, 'kerbau, kelinci, monyet, domba, kucing', '2026-04-29 07:50:57', '2026-05-17 06:41:12'),
(53, 'Yuni', 'Susilawati Indah Permata', 'yuni53', '$2a$10$LV7W/BCmv3isTAk4kBhFKOxth2tOUMhtMudGT0A/7SuRQE.bL2dIS', 'yuni.susilawatiindahpermata@abpaw.com', 'Jl. Bantul Km 14', '088334455667', 'Spesialis Penyakit Dalam', 150000.00, 'domba, kerbau, musang', '2026-04-29 07:50:57', '2026-05-17 06:41:12'),
(54, 'Zaskia', 'Adinda Meutia Hafsari', 'zaskia54', '$2a$10$3Ru2dd0zBaeNyYQNW4pTzOWYhj..THV0MBrn1vmm08JGXn/7XpiKW', 'zaskia.adindameutiahafsari@abpaw.com', 'Jl. Godean Km 10', '089445566778', 'Spesialis Parasitologi & Infeksi', 150000.00, 'babi, kelinci, kambing', '2026-04-29 07:50:57', '2026-05-17 06:41:12'),
(55, 'Agus', 'Salim Nur Hasanudin', 'agus55', '$2a$10$pyh8.vjLiyZR9DIPBpeqcOqlXAxW6DBjXW/EFKPGjHTBhVBloL3/O', 'agus.salimnurhasanudin@abpaw.com', 'Jl. Kaliurang Km 18', '081778899001', 'Spesialis Reproduksi', 150000.00, 'sapi, kambing, kucing', '2026-04-29 07:50:57', '2026-05-17 06:41:12'),
(56, 'Aneska', 'Zoya Raveena', 'aneska56', '$2a$10$lLdnOIC3EKoJjLbUzkuSluOGd3hp5C1r2au5IHkyOYakipy0bCh0O', 'aneska.zoyaraveena@abpaw.com', 'Jl. Kaliurang No. 45', '081234567891', 'Dokter Umum', 80000.00, 'ayam, ikan, sapi, kambing', '2026-04-29 07:58:43', '2026-05-17 06:41:13'),
(57, 'Arisha', 'Yonna Tanu', 'arisha57', '$2a$10$ProPbwAl4q81o3oqRgO8CONdjPy9xPAyGLZFaU6KPR1eUGp8q0bEm', 'arisha.yonnatanu@abpaw.com', 'Jl. Gejayan No. 12', '082345678912', 'Spesialis Bedah', 150000.00, 'musang, kambing, kuda', '2026-04-29 07:58:43', '2026-05-17 06:41:13'),
(58, 'Alesha', NULL, 'alesha58', '$2a$10$E58Bz3nxYbLXWunMmskF1O/SRRaA89yEqsU3nePjWQfSONnggtpTq', '', 'Jl. Colombo No. 78', '083456789123', 'Spesialis Kulit', 150000.00, 'kuda, kucing, babi, kambing, anjing', '2026-04-29 07:58:43', '2026-05-17 06:41:13'),
(59, 'Aresha', 'Ravan Arabella', 'aresha59', '$2a$10$aJT6Jy5FLmSeg01FsLRMhObzWrQvmCgldP491jFOnQ3bb4BObpmfC', 'aresha.ravanarabella@abpaw.com', 'Jl. Magelang No. 56', '084567891234', 'Spesialis Gigi', 150000.00, 'ikan, sapi, ayam, babi', '2026-04-29 07:58:43', '2026-05-17 06:41:13'),
(60, 'Abila', 'Rezfan Azkadina', 'abila60', '$2a$10$rIZsV25EAgSVlli1zWX0QOjEob68mAaAvru9ZLOtJ8oQ.qCLH1W1W', 'abila.rezfanazkadina@abpaw.com', 'Jl. Affandi No. 34', '085678912345', 'Dokter Umum', 80000.00, 'landak, kerbau, ayam, ikan', '2026-04-29 07:58:43', '2026-05-17 06:41:13'),
(61, 'Aurora', 'Ridha Zetana', 'aurora61', '$2a$10$01GpB92/23XFvKLwRS5JLehxcmYyUg/lOJMIoaJRFLnf1R/6Djmrm', 'aurora.ridhazetana@abpaw.com', 'Jl. Bantul No. 67', '086789123456', 'Spesialis Parasitologi & Infeksi', 150000.00, 'burung, monyet, hamster, kambing', '2026-04-29 07:58:43', '2026-05-17 06:41:14'),
(62, 'Aariz', 'Abrar Maalik', 'aariz62', '$2a$10$k.mKhmDzhw59zGdiC8xW6eOadYUZJYZMljoLN71NmJjMja0MfSEL.', 'aariz.abrarmaalik@abpaw.com', 'Jl. Seturan No. 89', '087891234567', 'Dokter Umum', 80000.00, 'kelinci, kura-kura, anjing', '2026-04-29 07:58:43', '2026-05-17 06:41:14'),
(63, 'Abid', 'Azhar Mubarak', 'abid63', '$2a$10$F7VltR.mFNGpM9npLmutZ./UK0AvhsHIFm5aMyauvjPLzUj4m6zzS', 'abid.azharmubarak@abpaw.com', 'Jl. Babarsari No. 23', '088912345678', 'Spesialis Reproduksi', 150000.00, 'anjing, ikan, hamster', '2026-04-29 07:58:43', '2026-05-17 06:41:14'),
(64, 'Adnan', 'Aiman Hafidz', 'adnan64', '$2a$10$bMayyQAsTm6x5udFnpbGTOzhCTGfc7nZwbOcu9nIqBeYf6EpSPGFu', 'adnan.aimanhafidz@abpaw.com', 'Jl. Janti No. 45', '089123456789', 'Spesialis Gigi', 150000.00, 'kura-kura, hamster, kerbau, kuda, ayam', '2026-04-29 07:58:43', '2026-05-17 06:41:14'),
(65, 'Aksa', 'Althaf Rafiqi', 'aksa65', '$2a$10$/tA5FBaFlqoAlUYesolhye78FIkCTw0G4vULTtMuEgc8McQcWKw5y', 'aksa.althafrafiqi@abpaw.com', 'Jl. Ringroad Utara No. 12', '081234567890', 'Spesialis Reproduksi', 150000.00, 'landak, kerbau, musang, domba', '2026-04-29 07:58:43', '2026-05-17 06:41:15'),
(66, 'Alif', 'Arsyad Ghazi', 'alif66', '$2a$10$39GDh80ioWVNjwhHLVnHhe27ot.abeQKqktLLbmYI4AcEhG7otAzS', 'alif.arsyadghazi@abpaw.com', 'Jl. Wates No. 34', '082345678901', 'Spesialis Penyakit Dalam', 150000.00, 'kerbau, hamster, landak, monyet, sapi', '2026-04-29 07:58:43', '2026-05-17 06:41:15'),
(67, 'Athalla', 'Alfarizi Akbar', 'athalla67', '$2a$10$69zYulOrA8ddE/gy6pGYM.XVB1xXnT8jMmVDmcR9253CQAflDfZeW', 'athalla.alfariziakbar@abpaw.com', 'Jl. Godean No. 56', '083456789012', 'Spesialis Penyakit Dalam', 150000.00, 'anjing, monyet, musang, hamster, sapi', '2026-04-29 07:58:43', '2026-05-17 06:41:15'),
(68, 'Azriel', 'Aqil Ibrahim', 'azriel68', '$2a$10$VXOu2hetI2OTTAU8solw6eQrwjF5vF1YoOwYbe0MmY67u1/HN45qG', 'azriel.aqilibrahim@abpaw.com', 'Jl. Parangtritis No. 78', '084567890123', 'Spesialis Penyakit Dalam', 150000.00, 'babi, hamster, kambing, kura-kura', '2026-04-29 07:58:43', '2026-05-17 06:41:16'),
(69, 'Bagas', 'Dewantara Sakti', 'bagas69', '$2a$10$C4vyf8sKWlMRlsqm9EyEm.rUCA6OlRAZyDK7qYVYPkU68irgYfdLq', 'bagas.dewantarasakti@abpaw.com', 'Jl. Imogiri No. 90', '085678901234', 'Spesialis Gigi', 150000.00, 'musang, sapi, hamster, kuda', '2026-04-29 07:58:43', '2026-05-17 06:41:16'),
(70, 'Bagaskara', 'Aditya Nugraha', 'bagaskara70', '$2a$10$NmMhRIhBCeInU4nLylvPxOMWVFSLAhJLpbjpvh/7fVMC0zqk/9NGq', 'bagaskara.adityanugraha@abpaw.com', 'Jl. Wonosari No. 11', '086789012345', 'Spesialis Parasitologi & Infeksi', 150000.00, 'kura-kura, sapi, kuda, domba, babi', '2026-04-29 07:58:43', '2026-05-17 06:41:16'),
(71, 'Baldwin', 'Aditya Wardhana', 'baldwin71', '$2a$10$byt1O6aUkw8jBAsfp5OC/Of596VFABzgTknle5HvRofsvgYSN7oue', 'baldwin.adityawardhana@abpaw.com', 'Jl. Prambanan No. 22', '087890123456', 'Spesialis Bedah', 150000.00, 'kelinci, sapi, ikan, kerbau', '2026-04-29 07:58:43', '2026-05-17 06:41:16'),
(72, 'Bara', 'Aditya Nugraha', 'bara72', '$2a$10$Uz7uJTIvnJB1XmZOXMb3KOhr80zuBhvFimFpYevYUyIaE3bVwDMvO', 'bara.adityanugraha@abpaw.com', 'Jl. Raya Yogya-Solo No. 33', '088901234567', 'Spesialis Parasitologi & Infeksi', 150000.00, 'monyet, kambing, ayam, kura-kura, hamster', '2026-04-29 07:58:43', '2026-05-17 06:41:17'),
(73, 'Barata', 'Wisnu Tama', 'barata73', '$2a$10$onz.welsfsItPYQGk6fVPuTw3XNYX.7SBJMLV9PQwWVUWw.uhVnZy', 'barata.wisnutama@abpaw.com', 'Jl. Raya Yogya-Magelang No. 44', '089012345678', 'Spesialis Gigi', 150000.00, 'domba, babi, kerbau, ayam, kuda', '2026-04-29 07:58:43', '2026-05-17 06:41:17'),
(74, 'Baruna', 'Jagat Raya', 'baruna74', '$2a$10$dopv4WP.L9SdMC6YWwQhV.B3nAWfpkucfIMgpNkR3lKgP7a3mwj3O', 'baruna.jagatraya@abpaw.com', 'Jl. Monjali No. 55', '081123456789', 'Spesialis Bedah', 150000.00, 'ikan, domba, kelinci', '2026-04-29 07:58:43', '2026-05-17 06:41:17'),
(75, 'Bhisma', 'Yudha Pratama', 'bhisma75', '$2a$10$8Q9/KS/1goxcxPf0FBSEaeyxqLEXkoB8c4pl0.2R9Zv7vkPL3guhC', 'bhisma.yudhapratama@abpaw.com', 'Jl. Sudirman No. 66', '082234567890', 'Spesialis Kulit', 150000.00, 'hamster, monyet, kucing', '2026-04-29 07:58:43', '2026-05-17 06:41:18'),
(76, 'Bryan', 'Kenzo Pratama', 'bryan76', '$2a$10$7kgxE0z.ufhfgdlG.bbIIu3cEogrZvNYM.4nVDB4k1Th1NAyqQjfa', 'bryan.kenzopratama@abpaw.com', 'Jl. Malioboro No. 77', '083345678901', 'Spesialis Kulit', 150000.00, 'anjing, kuda, landak, kucing', '2026-04-29 07:58:43', '2026-05-17 06:41:18'),
(77, 'Oded', 'Zhafran Athalla', 'oded77', '$2a$10$6rMVrmpQoETv7p706e1ZBeYkqDJbyI.BHvIapNdoWS1YzONoOqiDK', 'oded.zhafranathalla@abpaw.com', 'Jl. Sosrowijayan No. 88', '084456789012', 'Spesialis Kulit', 150000.00, 'ayam, domba, kucing', '2026-04-29 07:58:43', '2026-05-17 06:41:18'),
(78, 'Calvin', 'Alfarizi Pratama', 'calvin78', '$2a$10$KqJocYHoeyEmi6zKW91rXuNsysSba8U9PxZVDwAvOBtHYlzkyOzy6', 'calvin.alfarizipratama@abpaw.com', 'Jl. Pasar Kembang No. 99', '085567890123', 'Spesialis Bedah', 150000.00, 'burung, kucing, monyet, landak', '2026-04-29 07:58:43', '2026-05-17 06:41:18'),
(79, 'Daniswara', 'Bagus Kaizen', 'daniswara79', '$2a$10$co5gNbtKuljKDBwf2thCDe5H8l2VxJaTLCo6Je2sb10gwyw33unvu', 'daniswara.baguskaizen@abpaw.com', 'Jl. Taman Siswa No. 10', '086678901234', 'Spesialis Bedah', 150000.00, 'kelinci, ikan, burung, sapi', '2026-04-29 07:58:43', '2026-05-17 06:41:19'),
(80, 'Ethan', 'Zayn Adrian', 'ethan80', '$2a$10$AH2ClL7YwWDM40IBRv9Yqe1oQislX.GWudxXo/UCGsAtukE9VJcpy', 'ethan.zaynadrian@abpaw.com', 'Jl. Cik Di Tiro No. 20', '087789012345', 'Spesialis Parasitologi & Infeksi', 150000.00, 'ikan, burung, musang', '2026-04-29 07:58:43', '2026-05-17 06:41:19'),
(81, 'Fahreza', 'Zayn Hakim', 'fahreza81', '$2a$10$Zf9tLMNw2t9Kik.x9MHR4uRbFIqPFt3pyzeRI1iou60LN0IP1UFn2', 'fahreza.zaynhakim@abpaw.com', 'Jl. Prof. Dr. Sardjito No. 30', '088890123456', 'Spesialis Reproduksi', 150000.00, 'kelinci, kambing, ayam', '2026-04-29 07:58:43', '2026-05-17 06:41:19'),
(82, 'Ghifari', 'Dzaki Faza', 'ghifari82', '$2a$10$1l0De8MQIe7POU0xDZNOBOxOwP82mXXQ0iG8YHXDvtD05WzzCmjJG', 'ghifari.dzakifaza@abpaw.com', 'Jl. KHA Dahlan No. 40', '089901234567', 'Spesialis Kulit', 150000.00, 'anjing, musang, kerbau', '2026-04-29 07:58:43', '2026-05-17 06:41:19'),
(83, 'Harith', 'Rayyan Zahran', 'harith83', '$2a$10$wctT6uetTLnt0H32SdloV.vZN96Z89JZNJxvI2Ezzv1sA4cm80tCa', 'harith.rayyanzahran@abpaw.com', 'Jl. Urip Sumoharjo No. 50', '081012345678', 'Dokter Umum', 80000.00, 'ikan, kucing, ayam', '2026-04-29 07:58:43', '2026-05-17 06:41:19'),
(84, 'Irfan', 'Rizqi Abdullah', 'irfan84', '$2a$10$6Dod2TX8Iu6HnsnCVknHwuMt7/B2ilGZIGNU1LPZaWJpJ7rr1sVtC', 'irfan.rizqiabdullah@abpaw.com', 'Jl. Suryotomo No. 60', '082123456789', 'Spesialis Bedah', 150000.00, 'burung, kambing, sapi, kucing, anjing', '2026-04-29 07:58:43', '2026-05-17 06:41:19'),
(85, 'Jonathan', 'Noah Ezra', 'jonathan85', '$2a$10$Ex.Qwy/aRNPmWJYZXG9WzOx7IcMxA.qkJH7C8LQButmXyrk47NcF2', 'jonathan.noahezra@abpaw.com', 'Jl. Mayor Suryotomo No. 70', '083234567890', 'Spesialis Parasitologi & Infeksi', 150000.00, 'kura-kura, ayam, kelinci', '2026-04-29 07:58:43', '2026-05-17 06:41:19'),
(86, 'Kharis', 'Kaelan Aksa', 'kharis86', '$2a$10$zmcJJLvel2OCk4Bkh9c8Yej.gmK4XC6J47ziV9D5TxbGVwTtc3Rd6', 'kharis.kaelanaksa@abpaw.com', 'Jl. Brigjen Katamso No. 80', '084345678901', 'Spesialis Gigi', 150000.00, 'hamster, kambing, kuda', '2026-04-29 07:58:43', '2026-05-17 06:41:20'),
(87, 'Luthfi', 'Rafi Alfarizi', 'luthfi87', '$2a$10$4yJ8AilKaF8HMFizqc0wzuqxvXb2LNqY8p6L8EQcAJKiYlY8QYTQi', 'luthfi.rafialfarizi@abpaw.com', 'Jl. Kusumanegara No. 90', '085456789012', 'Spesialis Gigi', 150000.00, 'sapi, burung, landak', '2026-04-29 07:58:43', '2026-05-17 06:41:20'),
(88, 'Milan', 'Alvaro Putra', 'milan88', '$2a$10$Y3CKMjYLsDq.8chXfKlGXePQVngomc/Tr0nbT4HnoTpHb5A1IfbCi', 'milan.alvaroputra@abpaw.com', 'Jl. Adisucipto No. 100', '086567890123', 'Spesialis Penyakit Dalam', 150000.00, 'burung, kuda, kucing, landak, ayam', '2026-04-29 07:58:43', '2026-05-17 06:41:20'),
(89, 'Nathaniel', 'Kaelan Satria', 'nathaniel89', '$2a$10$AD2zgtfIyGFBluY9x5UEl.oHy0nOvYV1flKGx0Ys5xGCsvZ1z.oDe', 'nathaniel.kaelansatria@abpaw.com', 'Jl. Laksda Adisucipto No. 110', '087678901234', 'Dokter Umum', 80000.00, 'burung, kucing, hamster', '2026-04-29 07:58:43', '2026-05-17 06:41:20'),
(90, 'Prasetya', 'Dwipa Aji', 'prasetya90', '$2a$10$RvCRfqDKC8kNp/sj9yFBsu1kaL8ZwbQj8datnwA910tTLRIUsYtQ6', 'prasetya.dwipaaji@abpaw.com', 'Jl. Raya Janti No. 120', '088789012345', 'Spesialis Reproduksi', 150000.00, 'domba, ayam, kucing, kerbau, kambing', '2026-04-29 07:58:43', '2026-05-17 06:41:20'),
(91, 'Qamil', 'Haikal Athala', 'qamil91', '$2a$10$6LNQ7fmQNUUEIYnS6iPK1eSZwqZVgPpAWsRUU8UZCtTH6cJgAe8GW', 'qamil.haikalathala@abpaw.com', 'Jl. Ringroad Selatan No. 130', '089890123456', 'Spesialis Parasitologi & Infeksi', 150000.00, 'landak, musang, ikan', '2026-04-29 07:58:43', '2026-05-17 06:41:20'),
(92, 'Rayhan', 'Kaelan Narendra', 'rayhan92', '$2a$10$ZiHl4PVfSh9KMn42neobZuAcR8HB49gaK7oEEpVXOKsKMFMsslA86', 'rayhan.kaelannarendra@abpaw.com', 'Jl. Bantu No. 140', '081901234567', 'Spesialis Bedah', 150000.00, 'domba, kuda, landak, anjing', '2026-04-29 07:58:43', '2026-05-17 06:41:20'),
(93, 'Syafiq', 'Rizky Ananda', 'syafiq93', '$2a$10$U6G6mnqQtbXPJpQgAQs2fusTVAxcxNgtV0CJXNRZzZuRKXfiEOdk.', 'syafiq.rizkyananda@abpaw.com', 'Jl. Gamping No. 150', '082012345678', 'Spesialis Gigi', 150000.00, 'kerbau, monyet, sapi, kura-kura, musang', '2026-04-29 07:58:43', '2026-05-17 06:41:21'),
(94, 'Tegar', 'Bagaskara Wijaya', 'tegar94', '$2a$10$m1AoD6ox7euc270UKp.ReuaB7zVXjmtCFEeJN4FGQ/AJoqx0T6ShG', 'tegar.bagaskarawijaya@abpaw.com', 'Jl. Sagan No. 160', '083123456789', 'Spesialis Gigi', 150000.00, 'kura-kura, monyet, ayam, domba', '2026-04-29 07:58:43', '2026-05-17 06:41:21'),
(95, 'Uzair', 'Faza Azzam', 'uzair95', '$2a$10$CEeEBUwzly3stG3tNVvlJOLDdo6iWjAESzM/exo3CZNB/GUR9yjDC', 'uzair.fazaazzam@abpaw.com', 'Jl. C. Simanjuntak No. 170', '084234567890', 'Spesialis Kulit', 150000.00, 'ikan, kura-kura, babi', '2026-04-29 07:58:43', '2026-05-17 06:41:21'),
(96, 'Vincent', 'Ethan Alvaro', 'vincent96', '$2a$10$eITaPhxQYhEh4C.ni/SFc.L91xRuamSqv9FodcdNJVgTdg0j3ulLa', 'vincent.ethanalvaro@abpaw.com', 'Jl. Gedong Kuning No. 180', '085345678901', 'Spesialis Kulit', 150000.00, 'babi, hamster, kambing', '2026-04-29 07:58:43', '2026-05-17 06:41:21'),
(97, 'Warren', 'Kenzo Pratama', 'warren97', '$2a$10$wSXPut8sYR4vCL8yrIDJgOli9CpgF9CZgeaFRAjzOH3HOIMnlmItm', 'warren.kenzopratama@abpaw.com', 'Jl. Ngadisuryan No. 190', '086456789012', 'Spesialis Parasitologi & Infeksi', 150000.00, 'kambing, kerbau, hamster, ikan', '2026-04-29 07:58:43', '2026-05-17 06:41:21'),
(98, 'Yudhistira', 'Abhimanyu Arjuna', 'yudhistira98', '$2a$10$moYn56Ez5gPkjead/XIq0uKFklh9uQyVnhrBIff/Fh0WTg8hGAazK', 'yudhistira.abhimanyuarjuna@abpaw.com', 'Jl. Prawirotaman No. 200', '087567890123', 'Spesialis Parasitologi & Infeksi', 150000.00, 'ayam, kuda, kerbau, kambing, monyet', '2026-04-29 07:58:43', '2026-05-17 06:41:21'),
(99, 'Zhian', 'Farras Arshakalif', 'zhian99', '$2a$10$.asosgDqQteDqb7U4cWXH.Y75VOlnFlqCGrxW3SOf9V.3u1v26SNS', 'zhian.farrasarshakalif@abpaw.com', 'Jl. Tirtodipuran No. 210', '088678901234', 'Spesialis Kulit', 150000.00, 'monyet, sapi, kambing', '2026-04-29 07:58:43', '2026-05-17 06:41:21'),
(100, 'Bylbiss', 'El Haqqie', 'bylbiss100', '$2a$10$79urPbz.5FLPB6IraXV1LeuTQhiT/42l.VbAl3sClSJbpZapEi3Yq', 'bylbiss.elhaqqie@abpaw.com', 'Jl. Veteran No. 12', '088803178628', 'Spesialis Parasitologi & Infeksi', 150000.00, 'kelinci, musang, anjing, hamster', '2026-04-29 07:58:43', '2026-05-17 06:41:21'),
(101, 'Alifah', 'Chairul Munawar', 'alifah101', '$2a$10$oufarRUsqlwuIcutZrIkWevMdRaaCCmf/O.kFFuQm2EVn1LZ4dlfy', 'alifah.chairulmunawar@abpaw.com', 'Jl. Diponegoro No. 45', '081393706713', 'Spesialis Reproduksi', 150000.00, 'kerbau, kelinci, kura-kura', '2026-04-29 07:58:43', '2026-05-17 06:41:22'),
(102, 'Risya', 'Rizqiyah Haryati', 'risya102', '$2a$10$4As9nelueT3IBik3iRH6T.AaIGU1MXmhjosRkpuzCUrQbm9Lum7oC', 'risya.rizqiyahharyati@abpaw.com', 'Jl. Ahmad Yani No. 78', '088803178628', 'Dokter Umum', 80000.00, 'domba, kucing, hamster, kambing, kura-kura', '2026-04-29 07:58:43', '2026-05-17 06:41:22'),
(103, 'Agung', 'Dwi Ratna', 'agung103', '$2a$10$97jSORIOsqzhJTSXufCHeeOVILZ/.uOsMVgSitjymnyH5ofez6icy', 'agung.dwiratna@abpaw.com', 'Jl. Gatot Subroto No. 33', '081393706713', 'Spesialis Parasitologi & Infeksi', 150000.00, 'burung, musang, kuda, babi', '2026-04-29 07:58:43', '2026-05-17 06:41:22'),
(104, 'Hamim', 'Thohari', 'hamim104', '$2a$10$rBi/CtwqazxwOnfRvsioLOXe30xeOzjuLn/iFrHPlJJPZCD2UzZv2', 'hamim.thohari@abpaw.com', 'Jl. Sudirman No. 90', '088803178628', 'Spesialis Penyakit Dalam', 150000.00, 'kuda, burung, landak, hamster, anjing', '2026-04-29 07:58:43', '2026-05-17 06:41:22'),
(105, 'Siti', 'Azizah', 'siti105', '$2a$10$nrvq13ejVrxEqLcaEyS9.OL6syny1VBgVW0EQhXAQk5ocHH9VI0Ty', 'siti.azizah@abpaw.com', 'Jl. Pahlawan No. 21', '081393706713', 'Spesialis Bedah', 150000.00, 'kucing, burung, kelinci, musang', '2026-04-29 07:58:43', '2026-05-17 06:41:22'),
(106, 'Azza', 'Wulandari', 'azza106', '$2a$10$BmgnYS2jSV9UrthglIpF1eBqqgPM7xJwPB9w5SIdf6sCS9Mv7Otua', 'azza.wulandari@abpaw.com', 'Jl. Merdeka No. 55', '088803178628', 'Spesialis Gigi', 150000.00, 'landak, kura-kura, kambing, musang', '2026-04-29 07:58:43', '2026-05-17 06:41:22'),
(107, 'Khusnul', 'Khuluq', 'khusnul107', '$2a$10$ouVjQ/GnjX9JWRhlUEF0/eKJAjRLVxyKzT8h0ffCSRSxh/VE5K4iC', 'khusnul.khuluq@abpaw.com', 'Jl. Kartini No. 17', '081393706713', 'Dokter Umum', 80000.00, 'landak, kambing, domba', '2026-04-29 07:58:43', '2026-05-17 06:41:22'),
(108, 'Abid', 'Mustaauliya', 'abid108', '$2a$10$shZsNnt9AjvWOO4vikd4G.bDOjAmQEm77QeMfuJoFQrPuilQps54.', 'abid.mustaauliya@abpaw.com', 'Jl. Raya Bogor No. 66', '088803178628', 'Spesialis Penyakit Dalam', 150000.00, 'monyet, ayam, kuda', '2026-04-29 07:58:43', '2026-05-17 06:41:22');

-- --------------------------------------------------------

--
-- Table structure for table `kupon`
--

CREATE TABLE `kupon` (
  `id_kupon` int(11) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `diskon_persen` decimal(5,2) NOT NULL,
  `diskon_maks` decimal(10,2) NOT NULL,
  `minimal_pembelian` decimal(10,2) NOT NULL,
  `berlaku_hingga` date NOT NULL,
  `aktif` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kupon`
--

INSERT INTO `kupon` (`id_kupon`, `kode`, `deskripsi`, `diskon_persen`, `diskon_maks`, `minimal_pembelian`, `berlaku_hingga`, `aktif`, `created_at`) VALUES
(1, '86ppc9', 'Apalah yang penting dapet potongan', 30.00, 30000.00, 100000.00, '2026-06-09', 1, '2026-05-09 09:58:53'),
(2, '3D865W', '', 20.00, 7000.00, 150000.00, '2026-05-15', 1, '2026-05-14 00:47:15');

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE `obat` (
  `id_obat` int(11) NOT NULL,
  `nama_obat` varchar(100) NOT NULL,
  `deskripsi_obat` text DEFAULT NULL,
  `bentuk_obat` enum('tablet','kapsul','suntik','salep','cair') DEFAULT 'tablet',
  `harga` decimal(12,2) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `stok_minimal` int(11) DEFAULT 5,
  `tgl_kadaluarsa` date DEFAULT NULL,
  `perlu_resep` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`id_obat`, `nama_obat`, `deskripsi_obat`, `bentuk_obat`, `harga`, `stok`, `stok_minimal`, `tgl_kadaluarsa`, `perlu_resep`, `created_at`, `updated_at`) VALUES
(1, 'Amoksisilin Trihidrat', 'Antibiotik spektrum luas untuk infeksi saluran pernapasan dan kulit pada anjing & kucing', 'tablet', 125000.00, 245, 10, '2026-05-20', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(2, 'Amoksisilin Trihidrat 500 mg', 'Antibiotik untuk infeksi bakteri pada sapi dan kambing', 'kapsul', 210000.00, 98, 5, '2026-07-15', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(3, 'Amoksisilin Trihidrat suspensi', 'Suspensi oral untuk hewan kecil, rasa daging', 'cair', 175000.00, 156, 8, '2025-12-10', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(4, 'Amoksisilin injeksi', 'Injeksi intramuskular untuk demam dan metritis pada sapi', 'suntik', 325000.00, 67, 5, '2027-01-30', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(5, 'Amoksisilin salep luka', 'Salep topikal untuk infeksi luka pasca operasi', 'salep', 89000.00, 302, 15, '2026-09-12', 0, '2026-05-13 11:23:53', '2026-05-14 00:37:30'),
(6, 'Amoksisilin trihidrat 250 mg', 'Tablet kunyah untuk kucing, antibiotik oral', 'tablet', 98500.00, 203, 10, '2026-11-01', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(7, 'Amoksisilin sirup', 'Sirup antibiotik untuk anak anjing dan anak kucing', 'cair', 143000.00, 178, 12, '2027-02-18', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(8, 'Amoksisilin LA', 'Long acting suntik untuk infeksi sistemik pada ternak', 'suntik', 450000.00, 42, 5, '2026-04-22', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(9, 'Amoksisilin + Asam Klavulanat', 'Kombinasi untuk infeksi resisten pada hewan kesayangan', 'tablet', 289000.00, 134, 8, '2026-10-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(10, 'Amoksisilin powder', 'Serbuk larut untuk air minum ayam dan itik', 'cair', 99000.00, 410, 20, '2025-11-30', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(11, 'Enrofloksasin 10%', 'Antibiotik fluorokuinolon untuk infeksi saluran kemih dan pencernaan', 'suntik', 350000.00, 84, 5, '2026-06-14', 1, '2026-05-13 11:23:53', '2026-05-17 07:45:27'),
(12, 'Enrofloksasin tablet', 'Tablet untuk infeksi kulit kronis pada anjing', 'tablet', 167500.00, 214, 10, '2027-03-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(13, 'Enrofloksasin oral solution', 'Larutan oral untuk pengobatan kolibasilosis pada unggas', 'cair', 198000.00, 302, 15, '2025-09-25', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(14, 'Enrofloksasin kapsul', 'Kapsul untuk kucing dengan infeksi saluran pernapasan atas', 'kapsul', 189000.00, 121, 7, '2026-12-03', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(15, 'Enrofloksasin salep mata', 'Salep mata untuk konjungtivitis bakteri pada kucing dan anjing', 'salep', 124000.00, 97, 5, '2027-04-17', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(16, 'Enrofloksasin 5%', 'Suntik dosis rendah untuk anak sapi', 'suntik', 278000.00, 75, 5, '2026-08-19', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(17, 'Enrofloksasin 20% LA', 'Long acting untuk pengobatan BRD pada sapi potong', 'suntik', 590000.00, 33, 3, '2025-10-11', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(18, 'Enrofloksasin tetes telinga', 'Tetes telinga untuk otitis eksterna bakteri', 'cair', 87000.00, 256, 12, '2027-01-24', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(19, 'Enrofloksasin generik', 'Tablet generik untuk hewan ternak', 'tablet', 112000.00, 189, 10, '2026-09-30', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(20, 'Enrofloksasin injeksi veteriner', 'Injeksi steril untuk infeksi gram negatif', 'suntik', 412000.00, 51, 5, '2026-11-11', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(21, 'Ivermectin 1%', 'Antiparasit spektrum luas untuk kudis dan cacing pada sapi & kambing', 'suntik', 225000.00, 167, 8, '2027-02-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(22, 'Ivermectin oral paste', 'Pasta oral untuk kuda, pengobatan strongylus', 'cair', 345000.00, 62, 4, '2026-05-18', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(23, 'Ivermectin spot on', 'Spot on untuk kutu dan caplak pada anjing dan kucing', 'cair', 158000.00, 430, 20, '2026-12-29', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(24, 'Ivermectin tablet kunyah', 'Tablet rasa daging untuk pencegahan heartworm', 'tablet', 187500.00, 299, 15, '2027-03-15', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(25, 'Ivermectin 0.5%', 'Larutan topikal untuk pengobatan skabies pada kelinci', 'cair', 99000.00, 203, 10, '2026-07-07', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(26, 'Ivermectin injeksi 10 ml', 'Vial suntik untuk babi dan domba', 'suntik', 198000.00, 88, 5, '2025-11-20', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(27, 'Ivermectin pour-on', 'Pour-on untuk sapi perah, efektif melawan lalat dan caplak', 'cair', 475000.00, 45, 5, '2027-01-11', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(28, 'Ivermectin krim', 'Krim untuk kudis sarcoptic pada anjing', 'salep', 123000.00, 156, 8, '2026-09-14', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(29, 'Ivermectin 2%', 'Suntik konsentrat untuk kuda dan sapi', 'suntik', 529000.00, 29, 3, '2026-04-25', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(30, 'Ivermectin generik', 'Obat cacing broad spectrum untuk ayam kampung', 'cair', 67500.00, 512, 25, '2025-12-01', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(31, 'Metronidazol 250 mg', 'Antibiotik antiprotozoa untuk giardiasis pada anjing', 'tablet', 98000.00, 178, 10, '2026-10-20', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(32, 'Metronidazol suspensi', 'Suspensi oral untuk infeksi mulut dan gigi pada kucing', 'cair', 145000.00, 143, 7, '2027-04-03', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(33, 'Metronidazol injeksi', 'Suntik untuk abses hati pada sapi', 'suntik', 267000.00, 54, 5, '2026-06-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(34, 'Metronidazol kapsul', 'Kapsul untuk pengobatan periodontitis pada anjing', 'kapsul', 132000.00, 109, 6, '2025-09-17', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(35, 'Metronidazol salep', 'Salep untuk luka infeksi anaerob', 'salep', 79000.00, 221, 12, '2027-02-28', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(36, 'Metronidazol 500 mg', 'Dosis tinggi untuk diare berdarah pada kuda', 'tablet', 211000.00, 87, 5, '2026-12-12', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(37, 'Metronidazol Benzoil', 'Larutan palatable untuk anak anjing', 'cair', 168000.00, 192, 10, '2027-01-19', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(38, 'Metronidazol generik', 'Obat murah untuk ayam petelur', 'tablet', 55000.00, 398, 20, '2025-11-02', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(39, 'Metronidazol veteriner', 'Suntik untuk infeksi sistemik pada reptil', 'suntik', 324000.00, 34, 4, '2026-08-27', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(40, 'Metronidazol + Spiramycin', 'Kombinasi untuk infeksi campuran', 'kapsul', 278000.00, 67, 5, '2027-03-21', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(41, 'Doksisiklin HiklAt', 'Antibiotik tetrasiklin untuk ehrlichiosis dan borreliosis', 'tablet', 189000.00, 147, 8, '2026-05-11', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(42, 'Doksisiklin oral liquid', 'Larutan untuk mycoplasma pada unggas', 'cair', 212000.00, 210, 10, '2027-04-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(43, 'Doksisiklin injeksi', 'Suntik lambat untuk infeksi saluran pernapasan kucing', 'suntik', 410000.00, 41, 5, '2025-09-28', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(44, 'Doksisiklin kapsul', 'Kapsul untuk leptospirosis pada anjing', 'kapsul', 176500.00, 123, 7, '2026-11-17', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(45, 'Doksisiklin salep mata', 'Salep untuk keratokonjungtivitis pada sapi', 'salep', 99000.00, 184, 10, '2027-02-11', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(46, 'Doksisiklin 100 mg', 'Tablet dosis rendah untuk kucing', 'tablet', 134000.00, 275, 12, '2026-07-24', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(47, 'Doksisiklin monohidrat', 'Bubuk larut untuk air minum ayam', 'cair', 156000.00, 366, 15, '2025-12-15', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(48, 'Doksisiklin LA', 'Long acting untuk ternak domba', 'suntik', 498000.00, 28, 3, '2027-01-02', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(49, 'Doksisiklin generik', 'Obat tetrasiklin murah untuk babi', 'tablet', 89000.00, 401, 20, '2026-10-09', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(50, 'Doksisiklin krim', 'Krim topikal untuk infeksi kulit pada kuda', 'salep', 118000.00, 92, 5, '2025-11-18', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(51, 'Sefaleksin 500 mg', 'Antibiotik sefalosporin untuk infeksi kulit dan saluran kemih', 'kapsul', 215000.00, 132, 7, '2026-09-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(52, 'Sefaleksin tablet', 'Tablet untuk pioderma pada anjing', 'tablet', 198000.00, 164, 10, '2027-03-30', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(53, 'Sefaleksin suspensi', 'Suspensi rasa ayam untuk anak kucing', 'cair', 167000.00, 201, 12, '2026-06-18', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(54, 'Sefaleksin injeksi', 'Suntik untuk infeksi tulang pada sapi', 'suntik', 478000.00, 37, 4, '2025-10-07', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(55, 'Sefaleksin salep', 'Salep untuk abses kulit pada kelinci', 'salep', 103000.00, 155, 8, '2027-04-14', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(56, 'Sefaleksin 250 mg', 'Dosis kecil untuk kucing dan anjing kecil', 'kapsul', 154000.00, 198, 10, '2026-12-27', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(57, 'Sefaleksin sirup', 'Sirup untuk infeksi telinga pada anak anjing', 'cair', 188000.00, 117, 6, '2027-01-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(58, 'Sefaleksin generik', 'Obat murah untuk ayam pedaging', 'tablet', 87000.00, 378, 20, '2025-09-21', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(59, 'Sefaleksin LA', 'Long acting untuk pengobatan mastitis sapi', 'suntik', 589000.00, 22, 3, '2026-08-14', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(60, 'Sefaleksin tetes telinga', 'Tetes untuk otitis eksterna anjing', 'cair', 112000.00, 143, 8, '2026-11-04', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(61, 'Gentamisin sulfat', 'Antibiotik aminoglikosida untuk infeksi gram negatif', 'suntik', 295000.00, 86, 5, '2027-02-19', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(62, 'Gentamisin tetes mata', 'Tetes mata untuk konjungtivitis pada kuda', 'cair', 89000.00, 234, 12, '2026-05-29', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(63, 'Gentamisin salep kulit', 'Salep untuk infeksi luka bakar pada anjing', 'salep', 108000.00, 167, 10, '2027-03-07', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(64, 'Gentamisin krim', 'Krim untuk dermatitis pada kucing', 'salep', 97000.00, 189, 9, '2025-12-13', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(65, 'Gentamisin injeksi 100 mg', 'Vial suntik untuk sepsis pada anak sapi', 'suntik', 365000.00, 54, 5, '2026-09-22', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(66, 'Gentamisin tetes telinga', 'Tetes untuk otitis media pada kelinci', 'cair', 76000.00, 301, 15, '2027-01-26', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(67, 'Gentamisin + Betametason', 'Kombinasi dengan steroid untuk peradangan telinga', 'cair', 149000.00, 122, 7, '2026-10-10', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(68, 'Gentamisin generik', 'Suntik murah untuk unggas', 'suntik', 178000.00, 248, 15, '2025-11-08', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(69, 'Gentamisin salep mata', 'Salep steril untuk infeksi mata sapi', 'salep', 115000.00, 98, 5, '2026-07-31', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(70, 'Gentamisin oral', 'Larutan oral untuk infeksi saluran pencernaan (tidak umum)', 'cair', 199000.00, 43, 5, '2027-04-22', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(71, 'Ketokonazol salep', 'Antijamur untuk kurap (ringworm) pada anjing dan kucing', 'salep', 126000.00, 277, 12, '2026-08-08', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(72, 'Ketokonazol tablet', 'Tablet untuk infeksi jamur sistemik pada kucing', 'tablet', 234000.00, 135, 8, '2027-02-01', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(73, 'Ketokonazol sampo', 'Sampo antijamur untuk dermatitis Malassezia', 'cair', 189000.00, 212, 10, '2025-10-25', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(74, 'Ketokonazol krim', 'Krim untuk kandidiasis pada kuda', 'salep', 99000.00, 188, 10, '2026-12-19', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(75, 'Ketokonazol 200 mg', 'Tablet dosis untuk anjing besar', 'tablet', 267000.00, 79, 5, '2027-03-12', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(76, 'Ketokonazol suspensi', 'Suspensi oral untuk anak kucing', 'cair', 156000.00, 149, 8, '2026-06-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(77, 'Ketokonazol + Klorheksidin', 'Shampo kombinasi untuk kutu jamur', 'cair', 209000.00, 164, 10, '2025-09-14', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(78, 'Ketokonazol injeksi', 'Suntik untuk mikosis sistemik pada reptil', 'suntik', 487000.00, 25, 3, '2027-01-17', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(79, 'Ketokonazol generik', 'Salep murah untuk ternak kambing', 'salep', 68000.00, 402, 20, '2026-11-28', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(80, 'Ketokonazol 400 mg', 'Dosis tinggi untuk kuda', 'tablet', 345000.00, 41, 4, '2027-04-07', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(81, 'Fipronil spot on', 'Ektoparasitisida untuk kutu, caplak, dan pinjal pada anjing', 'cair', 187000.00, 389, 15, '2026-09-03', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(82, 'Fipronil semprot', 'Semprot untuk lingkungan dan kandang', 'cair', 167000.00, 213, 10, '2027-02-14', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(83, 'Fipronil + Metoprena', 'Kombinasi menghambat telur kutu', 'cair', 245000.00, 178, 12, '2025-12-06', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(84, 'Fipronil untuk kucing', 'Spot on khusus kucing, bebas resep', 'cair', 169000.00, 302, 15, '2026-10-17', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(85, 'Fipronil generik', 'Obat kutu murah untuk anjing kampung', 'cair', 89000.00, 567, 25, '2027-03-25', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(86, 'Fipronil 10%', 'Konsentrat untuk sapi', 'cair', 410000.00, 56, 5, '2026-07-12', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(87, 'Fipronil krim', 'Krim untuk pengobatan fokal pada kucing', 'salep', 99000.00, 145, 8, '2025-11-19', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(88, 'Fipronil tetes leher', 'Tetes praktis untuk anak anjing', 'cair', 119000.00, 324, 18, '2026-05-04', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(89, 'Fipronil + Etofenprox', 'Campuran untuk kutu kebal', 'cair', 289000.00, 98, 5, '2027-01-29', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(90, 'Fipronil kalung', 'Kalung anti kutu lepas lambat', 'cair', 367000.00, 72, 5, '2026-12-20', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(91, 'Prazikuantel tablet', 'Anticacing untuk cacing pita pada anjing dan kucing', 'tablet', 85000.00, 410, 20, '2026-08-15', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(92, 'Prazikuantel injeksi', 'Suntik untuk cacing pita pada sapi', 'suntik', 295000.00, 64, 5, '2027-04-01', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(93, 'Prazikuantel + Pirantel', 'Kombinasi broad spectrum untuk cacing gelang dan pita', 'tablet', 129000.00, 378, 15, '2025-09-09', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(94, 'Prazikuantel suspensi', 'Suspensi oral untuk kucing liar', 'cair', 112000.00, 201, 10, '2026-11-23', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(95, 'Prazikuantel 50 mg', 'Tablet kecil untuk anak kucing', 'tablet', 67000.00, 289, 12, '2027-02-20', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(96, 'Prazikuantel generik', 'Obat cacing pita murah untuk ayam', 'tablet', 49000.00, 522, 30, '2025-10-03', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(97, 'Prazikuantel kapsul', 'Kapsul untuk anjing ras besar', 'kapsul', 156000.00, 134, 7, '2026-12-08', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(98, 'Prazikuantel oral paste', 'Pasta untuk kuda', 'cair', 345000.00, 47, 4, '2027-03-18', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(99, 'Prazikuantel + Febantel', 'Kombinasi tri cacing untuk anjing', 'tablet', 198000.00, 167, 10, '2026-06-27', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(100, 'Prazikuantel 200 mg', 'Dosis dewasa untuk anjing', 'tablet', 176000.00, 203, 10, '2025-12-29', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(101, 'Meloksikam injeksi', 'AINS untuk nyeri dan inflamasi pada sapi dan kuda', 'suntik', 345000.00, 78, 5, '2026-09-12', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(102, 'Meloksikam oral suspensi', 'Suspensi rasa madu untuk anjing arthritis', 'cair', 189000.00, 198, 10, '2027-01-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(103, 'Meloksikam tablet', 'Tablet untuk nyeri pasca operasi pada kucing', 'tablet', 154000.00, 213, 12, '2026-11-29', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(104, 'Meloksikam 1%', 'Suntik untuk radang sendi pada kuda', 'suntik', 412000.00, 44, 4, '2025-10-14', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(105, 'Meloksikam generik', 'Obat anti inflamasi murah untuk babi', 'tablet', 89000.00, 312, 15, '2027-04-10', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(106, 'Meloksikam krim', 'Krim topikal untuk nyeri otot pada anjing', 'salep', 117000.00, 167, 9, '2026-07-23', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(107, 'Meloksikam oral gel', 'Gel oral untuk kucing senior', 'cair', 209000.00, 122, 7, '2026-12-02', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(108, 'Meloksikam LA', 'Long acting untuk sapi perah', 'suntik', 569000.00, 31, 3, '2027-02-08', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(109, 'Meloksikam 0.5 mg/ml', 'Suspensi dosis rendah untuk anak anjing', 'cair', 143000.00, 145, 8, '2025-11-24', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(110, 'Meloksikam + Parasetamol', 'Kombinasi untuk demam pada kuda', 'tablet', 267000.00, 68, 5, '2026-08-30', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(111, 'Karprofen tablet', 'AINS untuk osteoartritis anjing', 'tablet', 234000.00, 156, 8, '2026-05-15', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(112, 'Karprofen injeksi', 'Suntik untuk nyeri pasca operasi', 'suntik', 398000.00, 53, 5, '2027-03-27', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(113, 'Karprofen kunyah', 'Tablet rasa hati untuk anjing', 'tablet', 198000.00, 201, 10, '2025-09-20', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(114, 'Karprofen 100 mg', 'Dosis untuk anjing besar', 'tablet', 278000.00, 89, 5, '2026-12-14', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(115, 'Karprofen generik', 'Obat nyeri murah untuk kucing', 'tablet', 145000.00, 178, 10, '2027-01-23', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(116, 'Karprofen suspensi', 'Suspensi oral untuk anjing kecil', 'cair', 167000.00, 134, 8, '2026-10-07', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(117, 'Karprofen 50 mg', 'Tablet untuk terapi jangka panjang', 'tablet', 189000.00, 210, 12, '2025-11-11', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(118, 'Karprofen kapsul', 'Kapsul untuk nyeri panggul pada kuda', 'kapsul', 412000.00, 37, 4, '2027-02-25', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(119, 'Karprofen LA', 'Suntik lepas lambat untuk radang sendi', 'suntik', 589000.00, 26, 3, '2026-08-02', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(120, 'Karprofen oral paste', 'Paste untuk kuda dengan kolik ringan', 'cair', 356000.00, 42, 4, '2027-04-16', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(121, 'Prednisolon tablet', 'Kortikosteroid untuk alergi dan autoimun pada anjing', 'tablet', 112000.00, 245, 12, '2026-06-11', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(122, 'Prednisolon injeksi', 'Suntik untuk syok anafilaksis pada kucing', 'suntik', 235000.00, 96, 5, '2027-01-31', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(123, 'Prednisolon salep', 'Salep untuk dermatitis atopik', 'salep', 89000.00, 203, 10, '2025-12-07', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(124, 'Prednisolon oral solution', 'Larutan untuk asma kucing', 'cair', 157000.00, 132, 7, '2026-09-19', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(125, 'Prednisolon 5 mg', 'Tablet dosis rendah untuk anjing kecil', 'tablet', 76000.00, 312, 15, '2027-03-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(126, 'Prednisolon generik', 'Obat radang murah untuk ternak', 'tablet', 67000.00, 398, 20, '2026-10-23', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(127, 'Prednisolon krim', 'Krim untuk eksim pada kuda', 'salep', 104000.00, 145, 8, '2025-08-28', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(128, 'Prednisolon 20 mg', 'Dosis tinggi untuk penyakit autoimun', 'tablet', 167000.00, 88, 5, '2027-02-12', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(129, 'Prednisolon tetes mata', 'Tetes untuk uveitis pada anjing', 'cair', 98000.00, 176, 10, '2026-07-16', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(130, 'Prednisolon + Neomycin', 'Kombinasi untuk infeksi telinga', 'cair', 145000.00, 119, 6, '2025-11-26', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(131, 'Deksametason injeksi', 'Kortikosteroid kuat untuk syok dan edema serebral', 'suntik', 189000.00, 134, 8, '2026-08-21', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(132, 'Deksametason tablet', 'Tablet untuk pengobatan alergi kronis', 'tablet', 99000.00, 267, 12, '2027-04-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(133, 'Deksametason salep', 'Salep untuk radang kulit pada kucing', 'salep', 78000.00, 234, 10, '2025-10-19', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(134, 'Deksametason oral', 'Larutan oral untuk asma kuda', 'cair', 145000.00, 98, 5, '2026-12-25', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(135, 'Deksametason 2 mg', 'Dosis rendah untuk anak anjing', 'tablet', 56000.00, 345, 18, '2027-01-14', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(136, 'Deksametason generik', 'Murah untuk sapi dan kambing', 'suntik', 123000.00, 276, 15, '2026-09-27', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(137, 'Deksametason krim', 'Krim untuk dermatitis kontak', 'salep', 87000.00, 189, 10, '2025-12-30', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(138, 'Deksametason 5 mg', 'Dosis tinggi untuk syok', 'tablet', 134000.00, 101, 6, '2027-03-17', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(139, 'Deksametason tetes mata', 'Tetes untuk inflamasi mata pada kuda', 'cair', 89000.00, 156, 8, '2026-06-26', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(140, 'Deksametason LA', 'Long acting untuk arthritis sapi', 'suntik', 345000.00, 48, 4, '2025-10-10', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(141, 'Furosemid injeksi', 'Diuretik untuk edema paru dan gagal jantung pada anjing', 'suntik', 178000.00, 112, 7, '2027-01-21', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(142, 'Furosemid tablet', 'Tablet untuk hipertensi pada kucing', 'tablet', 89000.00, 245, 12, '2026-08-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(143, 'Furosemid oral solution', 'Larutan untuk gagal jantung kongestif', 'cair', 156000.00, 134, 8, '2025-11-16', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(144, 'Furosemid 50 mg', 'Dosis untuk anjing besar', 'tablet', 123000.00, 189, 10, '2027-02-04', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(145, 'Furosemid generik', 'Obat diuretik murah untuk sapi', 'suntik', 99000.00, 278, 15, '2026-10-18', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(146, 'Furosemid kapsul', 'Kapsul untuk terapi jangka panjang kucing', 'kapsul', 145000.00, 97, 5, '2025-09-30', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(147, 'Furosemid 20 mg', 'Dosis kecil untuk anjing kecil', 'tablet', 78000.00, 302, 15, '2027-03-28', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(148, 'Furosemid injeksi 100 mg', 'Konsentrat untuk kuda', 'suntik', 267000.00, 43, 4, '2026-07-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(149, 'Furosemid + Spironolakton', 'Kombinasi hemat kalium', 'tablet', 234000.00, 76, 5, '2026-12-01', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(150, 'Furosemid tetes', 'Tetes oral untuk anak kucing', 'cair', 112000.00, 156, 8, '2027-04-19', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(151, 'Atropin sulfat', 'Antikolinergik untuk bradikardia dan antidot organofosfat', 'suntik', 156000.00, 167, 10, '2026-05-08', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(152, 'Atropin tetes mata', 'Tetes untuk midriasis pada pemeriksaan mata kuda', 'cair', 89000.00, 201, 12, '2027-02-16', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(153, 'Atropin tablet', 'Tablet untuk kejang otot polos pada kucing', 'tablet', 108000.00, 134, 8, '2025-12-18', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(154, 'Atropin 0.5 mg', 'Dosis kecil untuk anak anjing', 'suntik', 98000.00, 213, 10, '2026-09-15', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(155, 'Atropin generik', 'Obat darurat untuk keracunan pestisida pada ayam', 'suntik', 67000.00, 345, 20, '2027-01-27', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(156, 'Atropin salep mata', 'Salep untuk ulkus kornea', 'salep', 79000.00, 178, 10, '2025-11-03', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(157, 'Atropin 1 mg', 'Dosis standar untuk anjing', 'suntik', 134000.00, 98, 5, '2026-08-14', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(158, 'Atropin oral', 'Larutan oral untuk kolik pada kuda', 'cair', 167000.00, 76, 5, '2027-03-03', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(159, 'Atropin + Pralidoksim', 'Paket antidot untuk keracunan insektisida', 'suntik', 389000.00, 34, 3, '2026-10-28', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(160, 'Atropin krim', 'Krim untuk kejang otot lokal', 'salep', 89000.00, 145, 8, '2025-09-22', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(161, 'Xilazin HCl 2%', 'Sedatif dan analgesik untuk prosedur minor pada sapi', 'suntik', 267000.00, 87, 5, '2026-06-19', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(162, 'Xilazin injeksi', 'Obat bius untuk kuda dan domba', 'suntik', 310000.00, 64, 5, '2027-01-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(163, 'Xilazin 100 mg/ml', 'Konsentrat untuk rusa', 'suntik', 456000.00, 22, 3, '2025-12-11', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(164, 'Xilazin generik', 'Sedatif murah untuk kambing', 'suntik', 189000.00, 112, 7, '2026-09-24', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(165, 'Xilazin + Ketamin', 'Kombinasi anestesi untuk anjing', 'suntik', 589000.00, 41, 4, '2027-03-20', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(166, 'Xilazin 20 mg', 'Dosis rendah untuk kucing liar', 'suntik', 156000.00, 98, 6, '2025-10-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(167, 'Xilazin oral gel', 'Gel untuk sedasi ringan pada kucing', 'cair', 234000.00, 67, 5, '2026-11-12', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(168, 'Xilazin 10%', 'Untuk imobilisasi sapi besar', 'suntik', 398000.00, 35, 4, '2027-02-28', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(169, 'Xilazin HCl powder', 'Serbuk larut untuk air minum ayam (sedasi transport)', 'cair', 345000.00, 28, 3, '2026-07-19', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(170, 'Xilazin 500 mg', 'Dosis tinggi untuk kuda', 'suntik', 567000.00, 19, 2, '2025-09-17', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(171, 'Ketamin HCl', 'Anestesi dissosiatif untuk induksi pada kucing', 'suntik', 345000.00, 76, 5, '2026-12-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(172, 'Ketamin 100 mg/ml', 'Vial untuk anjing dan kucing', 'suntik', 398000.00, 54, 5, '2027-01-25', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(173, 'Ketamin + Xilazin', 'Kombinasi untuk anestesi jangka pendek', 'suntik', 489000.00, 43, 4, '2025-11-29', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(174, 'Ketamin generik', 'Obat bius murah untuk hewan laboratorium', 'suntik', 234000.00, 98, 6, '2026-08-17', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(175, 'Ketamin 50 mg', 'Dosis untuk kucing kecil', 'suntik', 189000.00, 112, 7, '2027-04-12', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(176, 'Ketamin oral', 'Larutan oral (off-label) untuk sedasi burung', 'cair', 278000.00, 34, 3, '2025-10-21', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(177, 'Ketamin + Medetomidin', 'Kombinasi untuk anestesi pada kelinci', 'suntik', 589000.00, 27, 3, '2026-09-06', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(178, 'Ketamin 200 mg/ml', 'Konsentrat untuk kuda', 'suntik', 456000.00, 31, 4, '2027-02-22', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(179, 'Ketamin sediaan krim', 'Krim anestesi topikal (jarang)', 'salep', 189000.00, 56, 5, '2025-12-14', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(180, 'Ketamin HCl powder', 'Serbuk untuk rekonstitusi', 'suntik', 678000.00, 18, 2, '2026-10-02', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(181, 'Buprenorfin injeksi', 'Analgesik opioid untuk nyeri sedang-berat pada anjing', 'suntik', 410000.00, 67, 5, '2026-07-28', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(182, 'Buprenorfin oral', 'Larutan oral untuk nyeri pasca operasi kucing', 'cair', 345000.00, 89, 5, '2027-03-14', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(183, 'Buprenorfin tablet', 'Tablet sublingual untuk nyeri kronis', 'tablet', 289000.00, 54, 5, '2025-10-15', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(184, 'Buprenorfin 0.3 mg', 'Dosis kecil untuk kucing', 'suntik', 198000.00, 112, 7, '2026-12-16', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(185, 'Buprenorfin generik', 'Opioid murah untuk sapi', 'suntik', 267000.00, 43, 4, '2027-01-08', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(186, 'Buprenorfin patch', 'Patch transdermal untuk nyeri 72 jam', 'salep', 567000.00, 23, 3, '2025-09-26', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(187, 'Buprenorfin + Lidokain', 'Kombinasi untuk blok epidural pada kuda', 'suntik', 589000.00, 31, 3, '2026-11-07', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(188, 'Buprenorfin 0.6 mg', 'Dosis tinggi untuk anjing besar', 'suntik', 345000.00, 47, 4, '2027-02-18', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(189, 'Buprenorfin sirup', 'Sirup untuk nyeri pada hewan kecil', 'cair', 298000.00, 78, 6, '2026-04-29', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(190, 'Buprenorfin spray oral', 'Semprot mukosa untuk kucing', 'cair', 412000.00, 39, 4, '2025-12-03', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(191, 'Klindamisin tablet', 'Antibiotik untuk infeksi tulang dan abses gigi pada anjing', 'tablet', 234000.00, 134, 8, '2026-06-23', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(192, 'Klindamisin kapsul', 'Kapsul untuk toksoplasmosis pada kucing', 'kapsul', 267000.00, 98, 6, '2027-01-12', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(193, 'Klindamisin injeksi', 'Suntik untuk infeksi anaerob dalam', 'suntik', 412000.00, 56, 5, '2025-11-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(194, 'Klindamisin oral liquid', 'Larutan rasa daging untuk anak anjing', 'cair', 189000.00, 145, 10, '2026-09-30', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(195, 'Klindamisin salep', 'Salep untuk infeksi kulit dalam', 'salep', 134000.00, 167, 9, '2027-03-26', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(196, 'Klindamisin 150 mg', 'Dosis standar untuk kucing', 'tablet', 176000.00, 201, 10, '2025-10-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(197, 'Klindamisin generik', 'Antibiotik murah untuk ayam', 'kapsul', 89000.00, 345, 20, '2026-08-12', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(198, 'Klindamisin 300 mg', 'Dosis untuk anjing besar', 'tablet', 289000.00, 87, 5, '2027-02-01', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(199, 'Klindamisin krim', 'Krim untuk folikulitis', 'salep', 112000.00, 154, 8, '2025-12-22', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(200, 'Klindamisin + Gentamisin', 'Kombinasi untuk infeksi campuran', 'suntik', 498000.00, 41, 4, '2026-11-15', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(201, 'Tilosin tartrat', 'Antibiotik makrolida untuk infeksi Mycoplasma pada unggas', 'suntik', 278000.00, 112, 7, '2026-05-16', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(202, 'Tilosin oral powder', 'Serbuk larut untuk air minum ayam', 'cair', 189000.00, 345, 15, '2027-04-08', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(203, 'Tilosin 200 mg', 'Tablet untuk babi', 'tablet', 167000.00, 134, 8, '2025-09-18', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(204, 'Tilosin injeksi 10%', 'Untuk sapi dengan metritis', 'suntik', 345000.00, 78, 5, '2026-12-05', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(205, 'Tilosin generik', 'Obat murah untuk itik', 'cair', 99000.00, 412, 20, '2027-01-30', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(206, 'Tilosin kapsul', 'Kapsul untuk kucing dengan pneumonia', 'kapsul', 198000.00, 89, 5, '2025-11-27', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(207, 'Tilosin 50 mg/ml', 'Larutan untuk anak ayam', 'cair', 134000.00, 278, 12, '2026-07-09', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(208, 'Tilosin + Doksisiklin', 'Kombinasi untuk CRD kompleks', 'cair', 267000.00, 67, 5, '2027-03-19', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(209, 'Tilosin salep', 'Salep untuk infeksi kelenjar pada kuda', 'salep', 123000.00, 101, 6, '2025-10-27', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(210, 'Tilosin tartrat 100 g', 'Paket besar untuk peternakan', 'cair', 589000.00, 28, 3, '2026-09-10', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(211, 'Sulfadimetoksin tablet', 'Antibiotik sulfa untuk koksidiosis pada anjing', 'tablet', 89000.00, 267, 12, '2026-08-25', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(212, 'Sulfadimetoksin oral liquid', 'Larutan untuk koksidiosis sapi', 'cair', 145000.00, 189, 10, '2027-01-17', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(213, 'Sulfadimetoksin injeksi', 'Suntik untuk enteritis pada kambing', 'suntik', 198000.00, 112, 7, '2025-12-19', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(214, 'Sulfadimetoksin 500 mg', 'Dosis untuk kuda', 'tablet', 134000.00, 145, 8, '2026-10-11', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(215, 'Sulfadimetoksin generik', 'Obat koksidia murah untuk ayam', 'cair', 67000.00, 489, 25, '2027-02-24', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(216, 'Sulfadimetoksin + Trimetoprim', 'Kombinasi potensiasi', 'tablet', 189000.00, 156, 9, '2025-09-13', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(217, 'Sulfadimetoksin 250 mg', 'Dosis untuk kucing', 'tablet', 89000.00, 201, 10, '2026-11-19', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(218, 'Sulfadimetoksin kapsul', 'Kapsul untuk kelinci', 'kapsul', 112000.00, 134, 7, '2027-04-02', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(219, 'Sulfadimetoksin 20%', 'Suntik pekat untuk sapi', 'suntik', 278000.00, 54, 5, '2025-10-28', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(220, 'Sulfadimetoksin bubuk', 'Serbuk untuk dicampur pakan', 'cair', 345000.00, 67, 5, '2026-07-21', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(221, 'Tetrasiklin HCl tablet', 'Antibiotik spektrum luas untuk infeksi saluran pernapasan', 'tablet', 89000.00, 312, 15, '2027-03-08', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(222, 'Tetrasiklin salep mata', 'Salep untuk konjungtivitis pada sapi', 'salep', 67000.00, 244, 12, '2026-05-12', 0, '2026-05-13 11:23:53', '2026-05-14 02:21:31'),
(223, 'Tetrasiklin injeksi', 'Suntik untuk anaplasmosis pada sapi', 'suntik', 198000.00, 134, 8, '2025-11-04', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(224, 'Tetrasiklin oral powder', 'Bubuk larut untuk air minum ayam', 'cair', 123000.00, 456, 20, '2026-09-17', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(225, 'Tetrasiklin 500 mg', 'Kapsul untuk anjing besar', 'kapsul', 145000.00, 178, 10, '2027-01-10', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(226, 'Tetrasiklin generik', 'Obat murah untuk babi', 'tablet', 56000.00, 567, 30, '2025-12-09', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(227, 'Tetrasiklin krim', 'Krim untuk infeksi kulit pada kucing', 'salep', 78000.00, 189, 10, '2026-08-01', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(228, 'Tetrasiklin 250 mg', 'Dosis untuk kucing', 'kapsul', 99000.00, 223, 12, '2027-02-27', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(229, 'Tetrasiklin + Colistin', 'Kombinasi untuk diare pada sapi', 'suntik', 345000.00, 67, 5, '2026-10-14', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(230, 'Tetrasiklin HCl 10%', 'Larutan suntik konsentrat', 'suntik', 267000.00, 54, 5, '2025-09-24', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(231, 'Kloramfenikol tablet', 'Antibiotik (penggunaan terbatas) untuk infeksi berat', 'tablet', 156000.00, 89, 5, '2026-06-02', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(232, 'Kloramfenikol injeksi', 'Suntik untuk salmonellosis pada kuda', 'suntik', 278000.00, 43, 4, '2027-03-23', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(233, 'Kloramfenikol salep mata', 'Salep untuk keratitis pada anjing', 'salep', 89000.00, 134, 8, '2025-10-16', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(234, 'Kloramfenikol oral', 'Larutan untuk infeksi sistemik pada kucing', 'cair', 189000.00, 67, 5, '2026-12-21', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(235, 'Kloramfenikol 250 mg', 'Kapsul untuk kambing', 'kapsul', 123000.00, 98, 6, '2027-01-28', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(236, 'Kloramfenikol generik', 'Murah untuk ayam (dilarang untuk petelur)', 'tablet', 89000.00, 345, 18, '2025-11-12', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(237, 'Kloramfenikol + Deksametason', 'Kombinasi untuk infeksi mata', 'salep', 145000.00, 112, 7, '2026-08-28', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(238, 'Kloramfenikol 500 mg', 'Dosis untuk sapi', 'tablet', 234000.00, 56, 5, '2027-02-09', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(239, 'Kloramfenikol PA', 'Long acting untuk pneumonia', 'suntik', 398000.00, 32, 3, '2025-12-24', 1, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(240, 'Kloramfenikol tetes telinga', 'Tetes untuk otitis media kronis', 'cair', 108000.00, 144, 9, '2026-09-09', 0, '2026-05-13 11:23:53', '2026-05-14 03:45:05'),
(241, 'Vitamin B12 injeksi', 'Suplemen untuk anemia dan defisiensi pada sapi', 'suntik', 89000.00, 412, 20, '2026-07-13', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(242, 'Vitamin B12 tablet', 'Tablet kunyah untuk kucing tua', 'tablet', 67000.00, 378, 18, '2027-04-11', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(243, 'Vitamin B12 oral liquid', 'Larutan untuk ayam stress', 'cair', 56000.00, 534, 25, '2025-10-08', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(244, 'Vitamin B12 + Besi', 'Kombinasi untuk mengatasi anemia pada babi', 'suntik', 134000.00, 267, 12, '2026-11-24', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(245, 'Vitamin B12 1000 mcg', 'Dosis tinggi untuk kuda', 'suntik', 123000.00, 189, 10, '2027-01-04', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(246, 'Vitamin B12 generik', 'Suplemen murah untuk kambing', 'tablet', 45000.00, 689, 30, '2025-09-19', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53'),
(247, 'Vitamin B12 500 mcg', 'Dosis untuk anjing', 'suntik', 78000.00, 299, 15, '2026-12-30', 0, '2026-05-13 11:23:53', '2026-05-16 00:46:02'),
(248, 'Vitamin B12 + Selenium', 'Kombinasi untuk distrofi otot pada domba', 'suntik', 156000.00, 140, 8, '2027-03-11', 0, '2026-05-13 11:23:53', '2026-05-16 00:46:32'),
(249, 'Vitamin B12 krim', 'Krim topikal untuk penyembuhan luka (tidak umum)', 'salep', 67000.00, 132, 8, '2025-11-23', 0, '2026-05-13 11:23:53', '2026-05-14 04:21:30'),
(250, 'Vitamin B12 kompleks', 'Dengan vitamin B1 dan B6 untuk neuropati', 'suntik', 189000.00, 210, 12, '2026-05-06', 0, '2026-05-13 11:23:53', '2026-05-13 11:23:53');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian_obat`
--

CREATE TABLE `pembelian_obat` (
  `id_pembelian` int(11) NOT NULL,
  `id_pemilik` int(11) NOT NULL,
  `id_obat` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga_satuan` decimal(15,2) NOT NULL,
  `total_harga` decimal(15,2) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(20) DEFAULT 'sukses',
  `kode_transaksi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembelian_obat`
--

INSERT INTO `pembelian_obat` (`id_pembelian`, `id_pemilik`, `id_obat`, `jumlah`, `harga_satuan`, `total_harga`, `tanggal`, `status`, `kode_transaksi`) VALUES
(8, 2, 249, 1, 67000.00, 67000.00, '2026-05-14 04:21:30', 'sukses', 'INV-OBT-1778732490210'),
(9, 2, 247, 1, 78000.00, 78000.00, '2026-05-16 00:46:02', 'sukses', 'INV-OBT-1778892362999'),
(10, 2, 248, 1, 156000.00, 156000.00, '2026-05-16 00:46:32', 'sukses', 'INV-OBT-1778892392137'),
(11, 6, 11, 2, 350000.00, 700000.00, '2026-05-17 07:41:48', 'sukses', 'INV-OBT-1779003708865'),
(12, 6, 11, 2, 350000.00, 700000.00, '2026-05-17 07:45:27', 'sukses', 'INV-OBT-1779003927595');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan_offline`
--

CREATE TABLE `pemesanan_offline` (
  `id_antrean` int(11) NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `id_pemilik` int(11) NOT NULL,
  `id_pet` int(11) NOT NULL,
  `nomor_antrean` varchar(20) NOT NULL,
  `tanggal_antrean` date NOT NULL,
  `waktu_antrean` time NOT NULL,
  `keluhan` text DEFAULT NULL,
  `biaya_jasa` decimal(15,2) DEFAULT 0.00,
  `total_biaya` decimal(15,2) DEFAULT 0.00,
  `status_antrean` enum('menunggu','diproses','selesai','batal') DEFAULT 'menunggu',
  `status_pembayaran` enum('belum_bayar','lunas') DEFAULT 'belum_bayar',
  `estimasi_waktu` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pemesanan_offline`
--

INSERT INTO `pemesanan_offline` (`id_antrean`, `id_dokter`, `id_pemilik`, `id_pet`, `nomor_antrean`, `tanggal_antrean`, `waktu_antrean`, `keluhan`, `biaya_jasa`, `total_biaya`, `status_antrean`, `status_pembayaran`, `estimasi_waktu`, `created_at`, `updated_at`) VALUES
(5, 1, 2, 1, 'ANT-20260514-001', '2026-05-14', '15:00:00', '', 0.00, 0.00, 'menunggu', 'belum_bayar', NULL, '2026-05-14 04:21:21', '2026-05-14 04:21:21'),
(6, 19, 2, 1, 'ANT-20260514-001', '2026-05-14', '08:00:00', '', 0.00, 0.00, 'menunggu', 'belum_bayar', NULL, '2026-05-14 06:47:10', '2026-05-14 06:47:10'),
(7, 13, 2, 2, 'ANT-20260516-001', '2026-05-16', '09:00:00', 'mencret tiap hari', 0.00, 0.00, 'menunggu', 'belum_bayar', NULL, '2026-05-16 00:47:23', '2026-05-16 00:47:23'),
(8, 17, 2, 1, 'ANT-20260516-001', '2026-05-16', '10:00:00', 'pincang', 0.00, 0.00, 'menunggu', 'belum_bayar', NULL, '2026-05-16 01:14:55', '2026-05-16 01:14:55'),
(9, 55, 2, 1, 'ANT-20260516-001', '2026-05-16', '16:00:00', '', 0.00, 0.00, 'menunggu', 'belum_bayar', NULL, '2026-05-16 07:17:41', '2026-05-16 07:17:41'),
(11, 55, 3, 6, 'ANT-20260516-002', '2026-05-16', '16:00:00', '', 0.00, 0.00, 'menunggu', 'belum_bayar', NULL, '2026-05-16 07:19:14', '2026-05-16 07:19:14');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan_online`
--

CREATE TABLE `pemesanan_online` (
  `id_pemesanan` int(11) NOT NULL,
  `kode_pemesanan` varchar(20) NOT NULL,
  `id_pemilik` int(11) NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `id_pet` int(11) NOT NULL,
  `tanggal_konsultasi` date NOT NULL,
  `waktu_konsultasi` varchar(5) NOT NULL,
  `keluhan` text NOT NULL,
  `biaya_konsultasi` decimal(10,2) NOT NULL,
  `kupon_digunakan` varchar(50) DEFAULT NULL,
  `jumlah_diskon` decimal(10,2) DEFAULT 0.00,
  `total_biaya` decimal(10,2) NOT NULL,
  `status_pemesanan` enum('menunggu','sudah bayar','diproses','selesai','batal') DEFAULT NULL,
  `waktu_pemesanan` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pemesanan_online`
--

INSERT INTO `pemesanan_online` (`id_pemesanan`, `kode_pemesanan`, `id_pemilik`, `id_dokter`, `id_pet`, `tanggal_konsultasi`, `waktu_konsultasi`, `keluhan`, `biaya_konsultasi`, `kupon_digunakan`, `jumlah_diskon`, `total_biaya`, `status_pemesanan`, `waktu_pemesanan`, `created_at`, `updated_at`) VALUES
(23, 'ONL1778732471158', 2, 3, 1, '2026-05-14', '11:21', '', 150000.00, NULL, 0.00, 150000.00, 'sudah bayar', '2026-05-14 11:21:11', '2026-05-14 04:21:11', '2026-05-14 04:21:11'),
(24, 'ONL1778733828539', 2, 1, 1, '2026-05-14', '11:43', '', 80000.00, NULL, 0.00, 80000.00, 'diproses', '2026-05-14 11:43:48', '2026-05-14 04:43:48', '2026-05-18 11:15:40'),
(25, 'ONL1778736903503', 2, 58, 1, '2026-05-14', '12:35', 'pingsan', 150000.00, '3D865W', 7000.00, 143000.00, 'sudah bayar', '2026-05-14 12:35:03', '2026-05-14 05:35:03', '2026-05-14 05:35:03'),
(26, 'ONL1778737531133', 2, 13, 1, '2026-05-14', '12:45', '', 150000.00, NULL, 0.00, 150000.00, 'sudah bayar', '2026-05-14 12:45:31', '2026-05-14 05:45:31', '2026-05-14 05:45:31'),
(27, 'ONL1778837158636', 2, 23, 1, '2026-05-15', '16:25', 'butuh paramex', 80000.00, NULL, 0.00, 80000.00, 'sudah bayar', '2026-05-15 16:25:58', '2026-05-15 09:25:58', '2026-05-15 09:25:58'),
(28, 'ONL1778912009524', 3, 5, 6, '2026-05-16', '13:13', 'mencret tiap hari', 150000.00, '86ppc9', 30000.00, 120000.00, 'diproses', '2026-05-16 13:13:29', '2026-05-16 06:13:29', '2026-05-16 13:05:49'),
(29, 'ONL1778931737852', 2, 5, 1, '2026-05-16', '18:42', '', 150000.00, '86ppc9', 30000.00, 120000.00, 'diproses', '2026-05-16 18:42:17', '2026-05-16 11:42:17', '2026-05-16 16:14:09'),
(30, 'ONL1778932113262', 3, 2, 6, '2026-05-16', '18:48', '', 150000.00, NULL, 0.00, 150000.00, 'sudah bayar', '2026-05-16 18:48:33', '2026-05-16 11:48:33', '2026-05-16 11:48:33'),
(31, 'ONL1778938834625', 1, 12, 7, '2026-05-16', '20:40', '', 80000.00, NULL, 0.00, 80000.00, 'sudah bayar', '2026-05-16 20:40:34', '2026-05-16 13:40:34', '2026-05-16 13:40:34'),
(32, 'ONL1778938861816', 1, 5, 7, '2026-05-16', '20:41', '', 150000.00, NULL, 0.00, 150000.00, 'sudah bayar', '2026-05-16 20:41:01', '2026-05-16 13:41:01', '2026-05-16 13:41:01'),
(33, 'ONL1778946343864', 1, 5, 7, '2026-05-16', '22:45', '', 150000.00, '86ppc9', 30000.00, 120000.00, 'sudah bayar', '2026-05-16 22:45:43', '2026-05-16 15:45:43', '2026-05-16 15:45:43'),
(34, 'ONL1778946594973', 1, 100, 7, '2026-05-16', '22:49', '', 150000.00, NULL, 0.00, 150000.00, 'sudah bayar', '2026-05-16 22:49:54', '2026-05-16 15:49:55', '2026-05-16 15:49:55'),
(35, 'ONL1779000256273', 6, 2, 9, '2026-05-17', '13:44', '', 150000.00, NULL, 0.00, 150000.00, 'selesai', '2026-05-17 13:44:16', '2026-05-17 06:44:16', '2026-05-17 08:20:53'),
(36, 'ONL1779006029105', 6, 2, 9, '2026-05-17', '15:20', '', 150000.00, NULL, 0.00, 150000.00, 'sudah bayar', '2026-05-17 15:20:29', '2026-05-17 08:20:29', '2026-05-17 08:20:29'),
(37, 'ONL1779109908501', 6, 2, 9, '2026-05-18', '20:11', '', 150000.00, NULL, 0.00, 150000.00, 'sudah bayar', '2026-05-18 20:11:48', '2026-05-18 13:11:48', '2026-05-18 13:11:48'),
(38, 'ONL1779110413223', 6, 1, 9, '2026-05-18', '20:20', '', 80000.00, NULL, 0.00, 80000.00, 'selesai', '2026-05-18 20:20:13', '2026-05-18 13:20:13', '2026-05-18 15:37:33'),
(39, 'ONL1779113399075', 6, 1, 9, '2026-05-18', '21:09', '', 80000.00, NULL, 0.00, 80000.00, 'selesai', '2026-05-18 21:09:59', '2026-05-18 14:09:59', '2026-05-18 15:37:41');

-- --------------------------------------------------------

--
-- Table structure for table `pemilik`
--

CREATE TABLE `pemilik` (
  `id_pemilik` int(11) NOT NULL,
  `nama_pemilik` varchar(100) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pemilik`
--

INSERT INTO `pemilik` (`id_pemilik`, `nama_pemilik`, `username`, `password`, `no_hp`, `email`, `alamat`, `created_at`, `updated_at`) VALUES
(1, 'Aisyah Zafira', 'ais', '$2a$10$OI7OcnvGPXCKr7gZ7YJFueThzLkxgJ0aPIqrLHELLK09Br/Uss2ei', '08987654321', 'ais@gmail.com', 'Yogyakarta', '2026-05-09 01:30:07', '2026-05-17 06:41:00'),
(2, 'Kurbo Arzaq', 'kubro', '$2a$10$lQf2MSVlYP4izrohKlg4E.Ga7oOHWvL5hTD15doBTlt44zIzlXBTO', '088888888', 'qurbo@gmail.com', 'Jalan aja dulu', '2026-05-09 06:02:02', '2026-05-17 06:41:00'),
(3, 'Aldi', 'aldi', '$2a$10$qj12s.X9JCcbW0PQv4OEle0stgFdLMhrF2djUHochO3I5Ntqf29q6', '08', 'aldi@gmail.com', 'Yogyakarta', '2026-05-15 13:06:03', '2026-05-17 06:41:01'),
(4, 'adik kecil', 'adikecil', '$2a$10$.euVZ.VA7YU9oejvYPqPZuk6U3ltOdPvmZoQS5SCZSuo9K85yDaIq', '081393706713', 'manusiaimut@gmail.com', 'jalancurug', '2026-05-16 03:56:08', '2026-05-17 06:41:01'),
(5, 'alip', 'alip', '$2a$10$a8NUWSxM8uintmJQ471Ps.y3OaeGCH/Yha/zFBs2dft1BzyJYFu9i', '0888', 'alip@gmail.com', 'Jalanin aja dulu', '2026-05-16 04:29:23', '2026-05-17 06:41:01'),
(6, 'Adalah', 'ada', '$2a$10$nTRO0HUUg407KyufzwX8ZOAFy2nV6hcsax7Ozxbw3nsVlRA7JSpZW', '08888888888', 'ada@gmail.com', 'Adalah', '2026-05-17 01:57:22', '2026-05-17 06:41:01'),
(7, 'Aigoo', 'aigo', '$2a$10$swOLPPQ3ACQAJ3RT74tz9u6oi2mEA7M0gOqDYHQUSqzMf0MHq8dNa', '08888888888', 'aigoo@gmail.com', 'Adalah', '2026-05-18 09:06:54', '2026-05-18 09:06:54');

-- --------------------------------------------------------

--
-- Table structure for table `pets`
--

CREATE TABLE `pets` (
  `id_pet` int(11) NOT NULL,
  `id_pemilik` int(11) NOT NULL,
  `nama_pet` varchar(50) NOT NULL,
  `jenis_kelamin` enum('jantan','betina','tidak_diketahui') DEFAULT 'tidak_diketahui',
  `jenis_hewan` enum('sapi','kambing','kerbau','ayam','kucing','kelinci','anjing','hamster','burung','ikan','musang','kura-kura','landak','babi','kuda','domba','monyet') NOT NULL,
  `ras` varchar(50) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `usia` int(11) DEFAULT NULL,
  `berat` decimal(5,2) DEFAULT NULL,
  `sterilisasi` enum('sudah','belum') DEFAULT 'belum',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pets`
--

INSERT INTO `pets` (`id_pet`, `id_pemilik`, `nama_pet`, `jenis_kelamin`, `jenis_hewan`, `ras`, `tanggal_lahir`, `usia`, `berat`, `sterilisasi`, `created_at`, `updated_at`) VALUES
(1, 2, 'Kimiri', 'betina', 'kambing', 'Kampung', '2026-04-03', 0, 0.70, 'belum', '2026-05-09 06:02:02', '2026-05-16 11:41:52'),
(2, 2, 'Nyaong', 'betina', 'kucing', '', NULL, NULL, NULL, 'belum', '2026-05-14 04:39:36', '2026-05-14 04:39:36'),
(4, 4, 'belco', 'jantan', 'kucing', '', NULL, 5, 5.00, 'belum', '2026-05-16 03:57:29', '2026-05-16 03:57:29'),
(5, 5, 'Cirbo', 'jantan', 'ayam', '', NULL, NULL, NULL, 'sudah', '2026-05-16 04:29:23', '2026-05-16 04:29:23'),
(6, 3, 'Cobi', 'jantan', 'kambing', '', NULL, NULL, NULL, 'sudah', '2026-05-16 06:12:02', '2026-05-16 06:12:02'),
(7, 1, 'Rere', 'jantan', 'anjing', '', NULL, 0, NULL, 'belum', '2026-05-16 13:36:16', '2026-05-16 15:44:16'),
(8, 1, 'Arien', 'jantan', 'kambing', '', NULL, NULL, NULL, 'belum', '2026-05-16 15:45:24', '2026-05-16 15:45:24'),
(9, 6, 'Yiying', 'betina', 'domba', 'jawa', NULL, 0, NULL, 'belum', '2026-05-17 01:57:22', '2026-05-18 13:20:05'),
(10, 7, 'adalah', 'jantan', 'musang', '', NULL, NULL, NULL, 'belum', '2026-05-18 09:06:54', '2026-05-18 09:06:54');

-- --------------------------------------------------------

--
-- Table structure for table `resep_obat`
--

CREATE TABLE `resep_obat` (
  `id_resep` int(11) NOT NULL,
  `id_pemesanan` int(11) NOT NULL,
  `tipe_pemesanan` enum('online','offline') NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `id_apoteker` int(11) DEFAULT NULL,
  `tanggal_resep` date NOT NULL,
  `status` enum('belum_diproses','diproses','selesai','batal','diambil') NOT NULL DEFAULT 'belum_diproses',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resep_obat`
--

INSERT INTO `resep_obat` (`id_resep`, `id_pemesanan`, `tipe_pemesanan`, `id_dokter`, `id_apoteker`, `tanggal_resep`, `status`, `created_at`) VALUES
(1, 28, 'online', 5, NULL, '2026-05-16', 'belum_diproses', '2026-05-16 08:17:43'),
(2, 28, 'online', 5, NULL, '2026-05-16', 'belum_diproses', '2026-05-16 08:31:40'),
(3, 28, 'online', 5, NULL, '2026-05-16', 'belum_diproses', '2026-05-16 09:02:29'),
(4, 28, 'online', 5, NULL, '2026-05-16', 'belum_diproses', '2026-05-16 09:16:30'),
(5, 28, 'online', 5, NULL, '2026-05-16', 'belum_diproses', '2026-05-16 10:36:44'),
(6, 35, 'online', 2, NULL, '2026-05-17', 'diambil', '2026-05-17 07:38:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `unique_username` (`username`);

--
-- Indexes for table `alergi_pet`
--
ALTER TABLE `alergi_pet`
  ADD PRIMARY KEY (`id_alergi`),
  ADD KEY `id_pet` (`id_pet`),
  ADD KEY `id_obat` (`id_obat`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id_chat`);

--
-- Indexes for table `detail_resep`
--
ALTER TABLE `detail_resep`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `id_resep` (`id_resep`),
  ADD KEY `id_obat` (`id_obat`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id_dokter`),
  ADD UNIQUE KEY `unique_username` (`username`);

--
-- Indexes for table `kupon`
--
ALTER TABLE `kupon`
  ADD PRIMARY KEY (`id_kupon`),
  ADD UNIQUE KEY `kode` (`kode`);

--
-- Indexes for table `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`id_obat`);

--
-- Indexes for table `pembelian_obat`
--
ALTER TABLE `pembelian_obat`
  ADD PRIMARY KEY (`id_pembelian`),
  ADD UNIQUE KEY `kode_transaksi` (`kode_transaksi`),
  ADD KEY `id_pemilik` (`id_pemilik`),
  ADD KEY `id_obat` (`id_obat`);

--
-- Indexes for table `pemesanan_offline`
--
ALTER TABLE `pemesanan_offline`
  ADD PRIMARY KEY (`id_antrean`),
  ADD UNIQUE KEY `unique_antrean` (`id_dokter`,`tanggal_antrean`,`nomor_antrean`),
  ADD KEY `id_dokter` (`id_dokter`),
  ADD KEY `id_pemilik` (`id_pemilik`),
  ADD KEY `id_pet` (`id_pet`);

--
-- Indexes for table `pemesanan_online`
--
ALTER TABLE `pemesanan_online`
  ADD PRIMARY KEY (`id_pemesanan`),
  ADD UNIQUE KEY `kode_pemesanan` (`kode_pemesanan`),
  ADD KEY `id_pemilik` (`id_pemilik`),
  ADD KEY `id_dokter` (`id_dokter`),
  ADD KEY `id_pet` (`id_pet`);

--
-- Indexes for table `pemilik`
--
ALTER TABLE `pemilik`
  ADD PRIMARY KEY (`id_pemilik`),
  ADD UNIQUE KEY `unique_username` (`username`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- Indexes for table `pets`
--
ALTER TABLE `pets`
  ADD PRIMARY KEY (`id_pet`),
  ADD KEY `id_pemilik` (`id_pemilik`);

--
-- Indexes for table `resep_obat`
--
ALTER TABLE `resep_obat`
  ADD PRIMARY KEY (`id_resep`),
  ADD KEY `id_dokter` (`id_dokter`),
  ADD KEY `id_apoteker` (`id_apoteker`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `alergi_pet`
--
ALTER TABLE `alergi_pet`
  MODIFY `id_alergi` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id_chat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `detail_resep`
--
ALTER TABLE `detail_resep`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT for table `kupon`
--
ALTER TABLE `kupon`
  MODIFY `id_kupon` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `obat`
--
ALTER TABLE `obat`
  MODIFY `id_obat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- AUTO_INCREMENT for table `pembelian_obat`
--
ALTER TABLE `pembelian_obat`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pemesanan_offline`
--
ALTER TABLE `pemesanan_offline`
  MODIFY `id_antrean` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pemesanan_online`
--
ALTER TABLE `pemesanan_online`
  MODIFY `id_pemesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `pemilik`
--
ALTER TABLE `pemilik`
  MODIFY `id_pemilik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pets`
--
ALTER TABLE `pets`
  MODIFY `id_pet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `resep_obat`
--
ALTER TABLE `resep_obat`
  MODIFY `id_resep` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alergi_pet`
--
ALTER TABLE `alergi_pet`
  ADD CONSTRAINT `alergi_pet_ibfk_1` FOREIGN KEY (`id_pet`) REFERENCES `pets` (`id_pet`) ON DELETE CASCADE,
  ADD CONSTRAINT `alergi_pet_ibfk_2` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`) ON DELETE CASCADE;

--
-- Constraints for table `detail_resep`
--
ALTER TABLE `detail_resep`
  ADD CONSTRAINT `detail_resep_ibfk_1` FOREIGN KEY (`id_resep`) REFERENCES `resep_obat` (`id_resep`) ON DELETE CASCADE,
  ADD CONSTRAINT `detail_resep_ibfk_2` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`) ON DELETE CASCADE;

--
-- Constraints for table `pembelian_obat`
--
ALTER TABLE `pembelian_obat`
  ADD CONSTRAINT `pembelian_obat_ibfk_1` FOREIGN KEY (`id_pemilik`) REFERENCES `pemilik` (`id_pemilik`) ON DELETE CASCADE,
  ADD CONSTRAINT `pembelian_obat_ibfk_2` FOREIGN KEY (`id_obat`) REFERENCES `obat` (`id_obat`);

--
-- Constraints for table `pemesanan_offline`
--
ALTER TABLE `pemesanan_offline`
  ADD CONSTRAINT `pemesanan_offline_ibfk_1` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE CASCADE,
  ADD CONSTRAINT `pemesanan_offline_ibfk_2` FOREIGN KEY (`id_pemilik`) REFERENCES `pemilik` (`id_pemilik`) ON DELETE CASCADE,
  ADD CONSTRAINT `pemesanan_offline_ibfk_3` FOREIGN KEY (`id_pet`) REFERENCES `pets` (`id_pet`) ON DELETE CASCADE;

--
-- Constraints for table `pemesanan_online`
--
ALTER TABLE `pemesanan_online`
  ADD CONSTRAINT `pemesanan_online_ibfk_1` FOREIGN KEY (`id_pemilik`) REFERENCES `pemilik` (`id_pemilik`) ON DELETE CASCADE,
  ADD CONSTRAINT `pemesanan_online_ibfk_2` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE CASCADE,
  ADD CONSTRAINT `pemesanan_online_ibfk_3` FOREIGN KEY (`id_pet`) REFERENCES `pets` (`id_pet`) ON DELETE CASCADE;

--
-- Constraints for table `pets`
--
ALTER TABLE `pets`
  ADD CONSTRAINT `pets_ibfk_1` FOREIGN KEY (`id_pemilik`) REFERENCES `pemilik` (`id_pemilik`) ON DELETE CASCADE;

--
-- Constraints for table `resep_obat`
--
ALTER TABLE `resep_obat`
  ADD CONSTRAINT `resep_obat_ibfk_1` FOREIGN KEY (`id_dokter`) REFERENCES `dokter` (`id_dokter`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
